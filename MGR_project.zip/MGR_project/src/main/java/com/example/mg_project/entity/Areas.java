package com.example.mg_project.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.springframework.context.annotation.Lazy;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Areas {
    @Id
    @GeneratedValue
    private Long id;
private String areaName;
private String pincode;
@Lazy
@ManyToOne
private Cities cityId;
}
