package com.example.mg_project.service;


import java.util.List;

import com.example.mg_project.entity.AccountsLog;
import com.example.mg_project.entity.PurchaseInvoices;
import com.example.mg_project.entity.SalesInvoices;
import com.example.mg_project.entity.Stock;
import com.example.mg_project.response.DuePaymentsResponse;
import com.example.mg_project.response.DueReceipts;
import com.example.mg_project.response.HighestCustomerSales;
import com.example.mg_project.response.Highestsoldproducts;
import com.example.mg_project.response.Reorderlevelreports;


public interface ReportsService {
    

    List<SalesInvoices> GetDailySales(String invoiceDate);

    List<PurchaseInvoices> GetDailyPurchasesInvoices(String invoiceDate);

    List<Stock> GetStorewiseStock(long storeId);

    List<DuePaymentsResponse> GetDuePayments();

    List<DueReceipts> getDuereceipts();

    List<Highestsoldproducts> getHighestSoldItems();

    List<HighestCustomerSales> highestCustomerSales();

    List<Reorderlevelreports> getReorderlevelItems();

    List<AccountsLog> getAllAccountsLog();
    
}
