package com.example.mg_project.request.purchaserequest;

import java.util.Date;
import java.util.List;

import com.example.mg_project.entity.PurchaseOrders;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class GrnRequest {
    
    private PurchaseOrders poId;
    private Date receiveDate;
    List<GrnItemsRequest> grnir;
}
