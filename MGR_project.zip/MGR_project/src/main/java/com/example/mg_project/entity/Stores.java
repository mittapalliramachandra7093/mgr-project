package com.example.mg_project.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Stores {
    
@Id
private Long id;
private String code;
private String storeName;
private String address;
private String pincode;
private String latitude;
private String longitude;
@ManyToOne
private Areas areaId;
}
