package com.example.mg_project.request.purchaserequest;

import java.util.Date;
import java.util.List;

import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.Users;
import com.example.mg_project.entity.Vendors;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class PurchaseOrdersRequest {
     
    private Vendors vendor;
    private Stores storeId;
    private Users createdBy;
    private Date orderDate;
    private  List< PurchaseOrderItemsRequest> poir;


    
}
