package com.example.mg_project.reposiory.purchasesrepository;

import java.sql.Date;
import java.util.List;

import com.example.mg_project.entity.GoodsReceivedNotes;
import com.example.mg_project.entity.PurchaseOrders;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.Vendors;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GoodsReceivedNotesRepository extends JpaRepository<GoodsReceivedNotes,Long>
{

    List<GoodsReceivedNotes> findByReceiveDateBetween(Date fDate, Date tDate);

    List<GoodsReceivedNotes> findByStoreId(Stores storeId);

    List< GoodsReceivedNotes> findByVendorId(Vendors vendor);

    GoodsReceivedNotes findByPoId(PurchaseOrders poId);

    


    
  

    
}
