package com.example.mg_project.reposiory.salesrepository;

import com.example.mg_project.entity.Customers;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomersRepository extends JpaRepository<Customers,Long>
{
    
}
