package com.example.mg_project.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SalesOrderAddress {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
@OneToOne
private SalesOrder soIdId;
private String address;
private String pincode;
@ManyToOne
private Areas areaId;
private String latitude;
private String longitude;

    
}
