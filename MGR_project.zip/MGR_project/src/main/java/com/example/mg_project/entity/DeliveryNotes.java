package com.example.mg_project.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DeliveryNotes {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
@ManyToOne
private Customers customer;
private Date deliveryDate;
private Integer quantity;
@ManyToOne
private Stores storeId;
@OneToOne
private SalesOrder soId;
private Date createdDate;
@ManyToOne
private Users createdBy;
private Date modifiedDate;
@ManyToOne
private Users modifiedBy;

}
