package com.example.mg_project.reposiory.salesrepository;

import com.example.mg_project.entity.CustomerReceipts;
import com.example.mg_project.entity.SalesInvoices;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerReceiptsRepository extends JpaRepository<CustomerReceipts,Long>
{


    CustomerReceipts findByInvoiceId(SalesInvoices build);

    
    
}
