package com.example.mg_project.service;

import java.util.List;

import com.example.mg_project.entity.Category;
import com.example.mg_project.entity.Items;
import com.example.mg_project.entity.Stock;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.UOM;

public interface InventoryService {

    Category saveCategory(Category category);

    List<Category> allCategory(Category category);

    Category getCategoryById(long id);

    List<UOM> getAllUom(UOM uom);

    UOM getUomById(long id);

    Items saveItems(Items items);

    Items getItemsById(long id);

    List<Items> getAllItems(Items items);

    Stock saveStock(Stock stock);

    Stock getStockByItemId(Items itemId);

    List<Stock> getAllStock(Stock stock);

   List<Stock> getStockByStoreId(long storeId);
    
}
