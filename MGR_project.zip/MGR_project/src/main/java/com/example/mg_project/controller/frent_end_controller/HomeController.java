package com.example.mg_project.controller.frent_end_controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class HomeController 
{
    @GetMapping("jsp")
    public String j()
    {
        return "RegisteredSuccess";
    }
    @GetMapping("/mgr")
    public String home()
    {
        return "Home";
    }
    @GetMapping("/login")
    public String login()
    {
        return "Login";
    }
    @GetMapping("/registeredsuccess")
    public String registeredsuccess()
    {
        return "RegisteredSuccess";
    }
    @GetMapping("/areasregister")
    public String areasregister()
    {
        return "AreasRegister";
    }
    @GetMapping("/purchaseinvoicesregister")
    public String purchaseinvoicesregister()
    {
        return "PurchaseInvoicesRegister";
    }
    @GetMapping("/cityregister")
    public String cityregister()
    {
        return "CityRegister";
    }
    @GetMapping("/countryregister")
    public String countryregister()
    {
        return "CountryRegister";
    }
    @GetMapping("/deliverynoteregister")
    public String deliverynoteregister()
    {
        return "DeliveryNoteRegister";
    }
    @GetMapping("/salresorderaddressregister")
    public String salresorderaddressregister()
    {
        return "SalresOrderAddressRegister";
    }
    @GetMapping("/stateregister")
    public String statesregister()
    {
        return "StatesRegister";
    }
    @GetMapping("/storeregister")
    public String storeregister()
    {
        return "StoreRegister";
    }
    @GetMapping("/vendorregister")
    public String vendorsregisterer()
    {
        return "VendorsRegister";
    }
    @GetMapping("/stockregister")
    public String stockregister()
    {
        return "StockRegister";
    }
    @GetMapping("/categoryregister")
    public String categoryregister()
    {
        return "CategoryRegister";
    }
    @GetMapping("/itemregister")
    public String itemsregister()
    {
        return "ItemsRegister";
    }
   @GetMapping("/userregister")
    public String userregister()
    {
        return "UserRegister";
    }
   /* @GetMapping("/")
    public String ()
    {
        return "";
    }
    @GetMapping("/")
    public String ()
    {
        return "";
    }
    @GetMapping("/")
    public String ()
    {
        return "";
    }
    @GetMapping("/")
    public String ()
    {
        return "";
    }
    @GetMapping("/")
    public String ()
    {
        return "";
    }
    @GetMapping("/")
    public String ()
    {
        return "";
    }
    @GetMapping("/")
    public String ()
    {
        return "";
    }
    @GetMapping("/")
    public String ()
    {
        return "";
    }
    */

}
