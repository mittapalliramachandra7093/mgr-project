package com.example.mg_project.reposiory.salesrepository;

import java.time.LocalDateTime;
import java.util.List;

import com.example.mg_project.entity.Customers;
import com.example.mg_project.entity.SalesInvoices;
import com.example.mg_project.entity.Stores;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface SalesInvoicesRepository extends JpaRepository<SalesInvoices,Long>
{

    List<SalesInvoices> findByCustomer(Customers customer);

    List<SalesInvoices> findByInvoiceDateBetween(String fromDate, String toDate);

    List<SalesInvoices> findByStoreId(Stores storeId);
    List<SalesInvoices> findByInvoiceDate(java.sql.Date date);

    @Query(value = "SELECT * FROM sales_invoices WHERE invoice_date >= ?1 AND invoice_date <= ?2", nativeQuery = true)
    List<SalesInvoices> findByInvoiceDateCustom(String date1, String date2);

    List<SalesInvoices> findByInvoiceDateBetween(LocalDateTime statedateandtime, LocalDateTime enddateandtime);
}
