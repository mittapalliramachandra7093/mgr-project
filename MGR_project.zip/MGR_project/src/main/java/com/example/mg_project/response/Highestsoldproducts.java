package com.example.mg_project.response;

import lombok.Data;

@Data
public class Highestsoldproducts {
    private String itemCode;
    private String itemName;
    private Integer quantity;
    
}
