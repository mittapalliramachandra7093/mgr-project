package com.example.mg_project.request.salesrequest;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SalesOrderItemRequest {

    private long itemId;
private Integer quantity;
    
}
