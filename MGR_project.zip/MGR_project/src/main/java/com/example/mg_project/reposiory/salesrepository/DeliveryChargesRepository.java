package com.example.mg_project.reposiory.salesrepository;

import com.example.mg_project.entity.DeliveryCharges;
import com.example.mg_project.entity.DeliveryNotes;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface DeliveryChargesRepository extends JpaRepository<DeliveryCharges,Long>
{



    DeliveryCharges getByDnId(DeliveryNotes dnId);

    DeliveryCharges findByDnId(DeliveryNotes build);

}
