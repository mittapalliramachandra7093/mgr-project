package com.example.mg_project.response;



import java.util.Date;

import lombok.Data;

@Data
public class DueReceipts {

    private Date InvoiceDate;
   private String  InvoiceNumber;
    private String  CustomerName;
    private Double   InvoiceAmount;
    private Double Paid;
    private Double Due;
         
}
