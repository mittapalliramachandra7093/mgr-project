package com.example.mg_project.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;
import javax.el.ELException;

import com.example.mg_project.entity.AccountsLog;
import com.example.mg_project.entity.CashBankAccount;
import com.example.mg_project.entity.GoodsReceivedNoteItems;
import com.example.mg_project.entity.GoodsReceivedNotes;
import com.example.mg_project.entity.Items;
import com.example.mg_project.entity.PurchaseInvoiceItems;
import com.example.mg_project.entity.PurchaseInvoices;
import com.example.mg_project.entity.PurchaseOrderItems;
import com.example.mg_project.entity.PurchaseOrders;
import com.example.mg_project.entity.Stock;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.Users;
import com.example.mg_project.entity.VendorItems;
import com.example.mg_project.entity.VendorPayments;
import com.example.mg_project.entity.Vendors;
import com.example.mg_project.reposiory.inventoryrepository.AccountsLogRepository;
import com.example.mg_project.reposiory.inventoryrepository.CashBankAccountRepository;
import com.example.mg_project.reposiory.inventoryrepository.ItemsRepository;
import com.example.mg_project.reposiory.inventoryrepository.StockRepository;
import com.example.mg_project.reposiory.purchasesrepository.GoodsReceivedNoteItemsRepository;
import com.example.mg_project.reposiory.purchasesrepository.GoodsReceivedNotesRepository;
import com.example.mg_project.reposiory.purchasesrepository.PurchaseInvoiceItemsRepository;
import com.example.mg_project.reposiory.purchasesrepository.PurchaseInvoicesRepository;
import com.example.mg_project.reposiory.purchasesrepository.PurchaseOrderItemsRepository;
import com.example.mg_project.reposiory.purchasesrepository.PurchaseOrdersRepository;
import com.example.mg_project.reposiory.purchasesrepository.VendorItemsRepository;
import com.example.mg_project.reposiory.purchasesrepository.VendorPaymentsRepository;
import com.example.mg_project.reposiory.purchasesrepository.VendorsRepository;
import com.example.mg_project.request.purchaserequest.GrnRequest;
import com.example.mg_project.request.purchaserequest.PurchaseInvoicesRequest;
import com.example.mg_project.request.purchaserequest.PurchaseOrdersRequest;
import com.example.mg_project.request.purchaserequest.VendorPaymentsRequest;
import com.example.mg_project.servicestatus.ServiceStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PurchasesServiceImpl implements PurchasesService {
    @Autowired
    private VendorsRepository vendorsRepository;

    @Override
    public Vendors saveVendors(Vendors vendors) {

        return vendorsRepository.save(vendors);
    }

    @Override
    public List<Vendors> getVenders(Vendors vendors) {

        return vendorsRepository.findAll();
    }

    @Override
    public Vendors getVendersById(long id) {

        return vendorsRepository.findById(id).get();
    }

    @Autowired
    private VendorItemsRepository vendorItemsRepository;

    @Override
    public VendorItems saveVendorsItems(VendorItems vendoriItems) {

        return vendorItemsRepository.save(vendoriItems);
    }

    @Override
    public List<VendorItems> getVendorsItemsByVenderId(long vendorId) {

        return vendorItemsRepository.findByVendorId(vendorId);
    }

    @Autowired
    private StockRepository stockRepository;

    @Autowired
    private ItemsRepository itemsRepository;
    @Autowired
    private PurchaseOrdersRepository purchaseOrdersRepository;

    @Override
    public ServiceStatus savePurchaseOrders(PurchaseOrdersRequest por) {
        ServiceStatus ss = new ServiceStatus();
        try {
            // save Purchase Orders
            Double orderAmount = 0.0;
            Integer quantity = 0;
            PurchaseOrders po = new PurchaseOrders();
            po.setVendor(por.getVendor());
            po.setOrderDate(por.getOrderDate());
            po.setOrderAmount(orderAmount);
            po.setQuantity(quantity);
            po.setStoreId(por.getStoreId());
            po.setCreatedDate(por.getOrderDate());
            po.setCreatedBy(por.getCreatedBy());
            PurchaseOrders savepo = purchaseOrdersRepository.save(po);
            // save Purchase Order Items
            List<PurchaseOrderItems> poilist = new ArrayList<PurchaseOrderItems>();

            for (int i = 0; i < por.getPoir().size(); i++) {
                PurchaseOrderItems poiObj = new PurchaseOrderItems();
                Items items = itemsRepository.findById(por.getPoir().get(i).getItemId()).get();

                // puchase order items
                System.out.println("poi");
                poiObj.setPoId(new PurchaseOrders().builder().id(po.getId()).build());
                poiObj.setItemId(new Items().builder().id(por.getPoir().get(i).getItemId()).build());
                poiObj.setQuantity(por.getPoir().get(i).getQuantity());
                poiObj.setRate(items.getCostPrice());
                poiObj.setUomId(items.getUomId());
                poiObj.setPurchasePrice(items.getCostPrice() * por.getPoir().get(i).getQuantity());
                poilist.add(poiObj);
                quantity = quantity + poiObj.getQuantity();
                orderAmount = orderAmount + poiObj.getPurchasePrice();
            }
            purchaseOrderItemsRepository.saveAll(poilist);

            savepo.setOrderAmount(orderAmount);
            savepo.setQuantity(quantity);
            purchaseOrdersRepository.save(savepo);

            ss.setStatuesCode("200");
            ss.setMessage("PurchaseOrder success !!! & PurchaseOrderItems save ");

        } catch (Exception e) {
            ss.setStatuesCode("0");
            ss.setMessage("PurchaseOrder not success !!!");
        }

        return ss;
    }

    @Override
    public List<PurchaseOrders> getAllPurchaseOrders(PurchaseOrders purchaseOrders) {

        return purchaseOrdersRepository.findAll();
    }

    @Override // date is string
    public List<PurchaseOrders> GetBetweenPurchaseOrders(String fromDate, String toDate) {
        Date fDate = Date.valueOf(fromDate);// string to date convert(date is SQL-- import java.sql.Date;)
        Date tDate = Date.valueOf(toDate); // colum name
        return purchaseOrdersRepository.findByCreatedDateBetween(fDate, tDate);
    }

    @Override
    public List<PurchaseOrders> GetPurchasesOrdersByStoreId(long storeId) {

        return purchaseOrdersRepository.findByStoreIdId(storeId);
    }

    @Override
    public PurchaseOrders getPurchaseOrderById(long id) {

        return purchaseOrdersRepository.findById(id).get();
    }

    @Override
    public List<PurchaseOrders> getPurchaseOrdersbyVendorId(long vendorId) {

        return purchaseOrdersRepository.findByVendorId(vendorId);
    }

    @Autowired
    private PurchaseOrderItemsRepository purchaseOrderItemsRepository;

    @Override
    public List<PurchaseOrderItems> getPurchaseOrderItemsbyPOId(long id) {

        return purchaseOrderItemsRepository.findByPoIdId(id);
    }

    @Autowired
    private GoodsReceivedNotesRepository goodsReceivedNotesRepository;

    @Override
    public ServiceStatus saveGrn(GrnRequest grnRequest) {
        ServiceStatus ss = new ServiceStatus();
        try {
            // in po id pass find grn present or not
            GoodsReceivedNotes findgrn = goodsReceivedNotesRepository.findByPoId(grnRequest.getPoId());
            System.out.println(findgrn);
            if (findgrn == null)// if null grn not present then grn creat or not null grn present then grn will
                                // up date
            {
                // grn creat
                GoodsReceivedNotes grn = new GoodsReceivedNotes();
                PurchaseOrders po = purchaseOrdersRepository.findById(grnRequest.getPoId().getId()).get();// by po id to
                                                                                                          // find order
                                                                                                          // informashan
                Integer quantity = 0;
                grn.setPoId(new PurchaseOrders().builder().id(po.getId()).build());
                grn.setVendor(new Vendors().builder().id(po.getVendor().getId()).build());
                grn.setReceiveDate(grnRequest.getReceiveDate());
                grn.setCreatedBy(new Users().builder().id(po.getCreatedBy().getId()).build());
                grn.setCreatedDate(grnRequest.getReceiveDate());
                grn.setStoreId(new Stores().builder().id(po.getStoreId().getId()).build());
                grn.setQuantity(quantity);
                GoodsReceivedNotes savegrns = goodsReceivedNotesRepository.save(grn);// grn creat
                // in grn have more items
                // by use list save all grn items
                List<GoodsReceivedNoteItems> grnilist = new ArrayList<GoodsReceivedNoteItems>();
                for (int i = 0; i < grnRequest.getGrnir().size(); i++) {
                    System.out.println("grn--------------------1");
                    GoodsReceivedNoteItems grni = new GoodsReceivedNoteItems();
                    grni.setGrnId(new GoodsReceivedNotes().builder().id(savegrns.getId()).build());
                    grni.setItemId(new Items().builder().id(grnRequest.getGrnir().get(i).getItemId()).build());
                    grni.setQuantity(grnRequest.getGrnir().get(i).getQuantity());
                    Items items = itemsRepository.findById(grnRequest.getGrnir().get(i).getItemId()).get();
                    grni.setUomId(items.getUomId());
                    grnilist.add(grni);
                    quantity = quantity + grnRequest.getGrnir().get(i).getQuantity();
                }
                goodsReceivedNoteItemsRepository.saveAll(grnilist);
                grn.setQuantity(quantity);
                goodsReceivedNotesRepository.save(grn);

            }
            // else grn present then update the grn
            else {

                GoodsReceivedNotes grn = new GoodsReceivedNotes();
                PurchaseOrders po = purchaseOrdersRepository.findById(grnRequest.getPoId().getId()).get();
                Integer quantity = 0;
                grn.setId(findgrn.getId());
                grn.setPoId(findgrn.getPoId());
                grn.setVendor(findgrn.getVendor());
                grn.setReceiveDate(grnRequest.getReceiveDate());
                grn.setCreatedBy(findgrn.getCreatedBy());
                grn.setCreatedDate(findgrn.getCreatedDate());
                grn.setModifiedBy(new Users().builder().id(po.getCreatedBy().getId()).build());
                grn.setModifiedDate(grnRequest.getReceiveDate());
                grn.setStoreId(findgrn.getStoreId());
                grn.setQuantity(quantity);
                GoodsReceivedNotes savegrns = goodsReceivedNotesRepository.save(grn);
                List<GoodsReceivedNoteItems> grnilistup = new ArrayList<GoodsReceivedNoteItems>();

                for (int i = 0; i < grnRequest.getGrnir().size(); i++) {
                    GoodsReceivedNoteItems grni = new GoodsReceivedNoteItems();
                    grni.setGrnId(new GoodsReceivedNotes().builder().id(savegrns.getId()).build());
                    // check in grn all rade items present then up date item quantity or creat item
                    // in grnitens
                    GoodsReceivedNoteItems findgrni = goodsReceivedNoteItemsRepository
                            .findByItemId(new Items().builder().id(grnRequest.getGrnir().get(i).getItemId()).build());
                    System.out.println("--item present are not-------" + grnRequest.getGrnir().get(i).getItemId());
                    if (findgrni == null) {
                        System.out.println("if items not present         ");
                        grni.setItemId(new Items().builder().id(grnRequest.getGrnir().get(i).getItemId()).build());
                        grni.setQuantity((grnRequest.getGrnir().get(i).getQuantity()));
                        Items items = itemsRepository.findById(grnRequest.getGrnir().get(i).getItemId()).get();
                        grni.setUomId(items.getUomId());
                        grnilistup.add(grni);
                        quantity = quantity + (grnRequest.getGrnir().get(i).getQuantity() + findgrn.getQuantity());
                    } else {
                        System.out.println("else items  present ---------------------");
                        grni.setId(findgrni.getId());
                        grni.setItemId(findgrni.getItemId());
                        grni.setQuantity((grnRequest.getGrnir().get(i).getQuantity()) + findgrni.getQuantity());
                        Items items = itemsRepository.findById(grnRequest.getGrnir().get(i).getItemId()).get();
                        grni.setUomId(items.getUomId());
                        grnilistup.add(grni);
                        quantity = quantity + (grnRequest.getGrnir().get(i).getQuantity() + findgrni.getQuantity());
                    }
                }
                goodsReceivedNoteItemsRepository.saveAll(grnilistup);
                grn.setQuantity(quantity);
                goodsReceivedNotesRepository.save(grn);
            } 
            // stock
            List<Stock> stocklist = new ArrayList<Stock>();
            long overflowLevel = 0;
            long reorderLevel = 0;
            PurchaseOrders po = purchaseOrdersRepository.findById(grnRequest.getPoId().getId()).get();
            for (int i = 0; i < grnRequest.getGrnir().size(); i++) {
                Stock stockObj = new Stock();
                try {

                    Stock stock = stockRepository.findByStoreIdAndItemId(
                            new Stores().builder().id(po.getStoreId().getId()).build(),
                            new Items().builder().id(grnRequest.getGrnir().get(i).getItemId()).build());
                    stockObj.setId(stock.getId());
                    stockObj.setQuantity(stock.getQuantity() + grnRequest.getGrnir().get(i).getQuantity());
                    stockObj.setReorderLevel(stock.getReorderLevel());
                    stockObj.setOverflowLevel(stock.getOverflowLevel());
                    stockObj.setStoreId(stock.getStoreId());
                    stockObj.setItemId(stock.getItemId());
                    stocklist.add(stockObj);

                    // System.out.println("save stock---i "+stock.getId());

                } catch (NullPointerException e) {
                    System.out.println("stock start catch block");
                    stockObj.setQuantity(grnRequest.getGrnir().get(i).getQuantity());
                    stockObj.setReorderLevel(reorderLevel);
                    stockObj.setOverflowLevel(overflowLevel);
                    stockObj.setStoreId(new Stores().builder().id(po.getStoreId().getId()).build());
                    stockObj.setItemId(new Items().builder().id(grnRequest.getGrnir().get(i).getItemId()).build());
                    stocklist.add(stockObj);
                }
            }

            stockRepository.saveAll(stocklist);
            ss.setStatuesCode("200");
            ss.setMessage("GRN  GRNitems & stock saved success!!");
        } catch (Exception e) {
            ss.setStatuesCode("0");
            ss.setMessage("GRN  GRNitems & stock not saved--errors" + e);

        }

        return ss;
    }

    @Override
    public List<GoodsReceivedNotes> getAllGRN(GoodsReceivedNotes goodsReceivedNotes) {

        return goodsReceivedNotesRepository.findAll();
    }

    @Override
    public GoodsReceivedNotes getGRNById(long id) {

        return goodsReceivedNotesRepository.findById(id).get();
    }

    @Override
    public List<GoodsReceivedNotes> getBetweenDatesByGRNs(String fromDate, String toDate) {

        Date fDate = Date.valueOf(fromDate);
        Date tDate = Date.valueOf(toDate);

        return goodsReceivedNotesRepository.findByReceiveDateBetween(fDate, tDate);
    }

    @Override
    public List<GoodsReceivedNotes> getGRNByStoreId(Stores storeId) {

        return goodsReceivedNotesRepository.findByStoreId(storeId);
    }

    @Override
    public List<GoodsReceivedNotes> etGRNByVendorId(Vendors vendor) {

        return goodsReceivedNotesRepository.findByVendorId(vendor);
    }

    @Autowired
    private GoodsReceivedNoteItemsRepository goodsReceivedNoteItemsRepository;

    @Override
    public GoodsReceivedNoteItems getGRNItemsbyGRNId(GoodsReceivedNotes grnId) {

         //goodsReceivedNoteItemsRepository.findByGrnId(grnId);
         return null;
    }
    // PurchaseInvoices
    @Autowired
    private PurchaseInvoicesRepository purchaseInvoicesRepository;
    @Autowired
    private PurchaseInvoiceItemsRepository purchaseInvoiceItemsRepository;

    @Override
    public ServiceStatus savePurchaseInvoices(PurchaseInvoicesRequest pir) {
        
        ServiceStatus ss = new ServiceStatus();
        try {
        GoodsReceivedNotes grnStatues = goodsReceivedNotesRepository.findByPoId(pir.getPoId());
        if (grnStatues == null) 
        {
            Integer quantity=0;
            GoodsReceivedNotes grn = new GoodsReceivedNotes();
            grn.setPoId(pir.getPoId());
            grn.setCreatedBy(pir.getCreatedBy());
            grn.setCreatedDate(pir.getCreatedDate());
            grn.setQuantity(quantity);
            grn.setStoreId(pir.getStoreId());
            grn.setVendor(pir.getVendor());
            grn.setReceiveDate(pir.getCreatedDate());
            GoodsReceivedNotes grnSave= goodsReceivedNotesRepository.save(grn);
           List< GoodsReceivedNoteItems > grnilist=new ArrayList<>();
            for(int i=0;i<pir.getPiir().size();i++)
            {
                GoodsReceivedNoteItems grni=new GoodsReceivedNoteItems();
                grni.setGrnId(new GoodsReceivedNotes().builder().id(grnSave.getId()).build());
                grni.setItemId(new Items().builder().id(pir.getPiir().get(i).getItemId()).build());
                grni.setQuantity(pir.getPiir().get(i).getQuantity());
                Items items=itemsRepository.getById(pir.getPiir().get(i).getItemId());
                grni.setUomId(items.getUomId());
                grnilist.add(grni);
                quantity +=pir.getPiir().get(i).getQuantity();
            }
            grn.setQuantity(quantity);
            goodsReceivedNoteItemsRepository.saveAll(grnilist);
            goodsReceivedNotesRepository.save(grn);
        }
        else
        {
          
            GoodsReceivedNotes getgrn= goodsReceivedNotesRepository.findByPoId(pir.getPoId());
            List <GoodsReceivedNoteItems> getgrni= goodsReceivedNoteItemsRepository.findByGrnId(new GoodsReceivedNotes().builder().id(getgrn.getId()).build());
          
            Integer quantity=0;
            GoodsReceivedNotes grn = new GoodsReceivedNotes();
            grn.setPoId(pir.getPoId());
            grn.setCreatedBy(pir.getCreatedBy());
            grn.setCreatedDate(pir.getCreatedDate());
            grn.setQuantity(quantity);
            grn.setStoreId(pir.getStoreId());
            grn.setVendor(pir.getVendor());
            grn.setReceiveDate(pir.getCreatedDate());
            GoodsReceivedNotes grnSave= goodsReceivedNotesRepository.save(grn);
           List< GoodsReceivedNoteItems > grnilist=new ArrayList<>();
          int fq=0;
            for(int i=0;i<pir.getPiir().size();i++)
            {
            try{
                GoodsReceivedNoteItems findgrni=goodsReceivedNoteItemsRepository.findByGrnIdAndItemId(new GoodsReceivedNotes().builder().id(getgrn.getId()).build(),new Items().builder().id(pir.getPiir().get(i).getItemId()).build());
                fq=findgrni.getQuantity();
            }catch(NullPointerException e){fq=0;}
                GoodsReceivedNoteItems grni=new GoodsReceivedNoteItems();
                grni.setGrnId(new GoodsReceivedNotes().builder().id(grnSave.getId()).build());
                grni.setItemId(new Items().builder().id(pir.getPiir().get(i).getItemId()).build());
                grni.setQuantity(pir.getPiir().get(i).getQuantity()-fq);
                 Items items=itemsRepository.getById(pir.getPiir().get(i).getItemId());
                grni.setUomId(items.getUomId());
                grnilist.add(grni);
                quantity =quantity+pir.getPiir().get(i).getQuantity()-fq;
                
            }
            grn.setQuantity(quantity);
            goodsReceivedNoteItemsRepository.saveAll(grnilist);
    
            goodsReceivedNotesRepository.save(grn);
          
        
            
        }
        Double invoiceAmount = 0.0;
        Double dueAmount = 0.0;
        Integer quantity = 0;
        Double payamout=0.0;
            PurchaseInvoices pi = new PurchaseInvoices();
            pi.setInvoiceNo(pir.getInvoiceNo());
            pi.setInvoiceDate(pir.getInvoiceDate());
            pi.setDueAmount(dueAmount);
            pi.setInvoiceAmount(invoiceAmount);
            pi.setPaidAmount(payamout);
            pi.setPoId(pir.getPoId());
            pi.setQuantity(quantity);
            PurchaseOrders po = purchaseOrdersRepository.getById(pir.getPoId().getId());
            pi.setStoreId(po.getStoreId());
            pi.setVendor(po.getVendor());
            pi.setCreatedDate(pir.getInvoiceDate());
            pi.setCreatedBy(po.getCreatedBy());
            PurchaseInvoices savepi = purchaseInvoicesRepository.save(pi);
            List<PurchaseInvoiceItems> piilist = new ArrayList<PurchaseInvoiceItems>();
            for (int i = 0; i < pir.getPiir().size(); i++) {
                PurchaseInvoiceItems pii = new PurchaseInvoiceItems();
                pii.setInvoiceId(new PurchaseInvoices().builder().id(savepi.getId()).build());
                pii.setItemId(new Items().builder().id(pir.getPiir().get(i).getItemId()).build());
                pii.setQuantity(pir.getPiir().get(i).getQuantity());
                Items items = itemsRepository.getById(pir.getPiir().get(i).getItemId());
                pii.setRate(items.getCostPrice());
                pii.setTotalPrice(items.getCostPrice() * pir.getPiir().get(i).getQuantity());
                pii.setUomId(items.getUomId());
                piilist.add(pii);
                quantity += pir.getPiir().get(i).getQuantity();
                invoiceAmount += items.getCostPrice() * pir.getPiir().get(i).getQuantity();
            }
            purchaseInvoiceItemsRepository.saveAll(piilist);
            pi.setQuantity(quantity);
            pi.setInvoiceAmount(invoiceAmount);
            pi.setDueAmount(invoiceAmount);
            purchaseInvoicesRepository.save(pi);
          

            ss.setStatuesCode("200");
            ss.setMessage("okay");
        } catch (Exception e) {

            ss.setStatuesCode("0");
            ss.setMessage("errer-" + e);
        }
        return ss;
    }

    @Override
    public List<PurchaseInvoices> getAllPurchaseInvoices(PurchaseInvoices purchaseInvoices) {

        return purchaseInvoicesRepository.findAll();
    }

    @Override
    public PurchaseInvoices getPurchaseInvoicesById(long id) {

        return purchaseInvoicesRepository.findById(id).get();
    }

    @Override
    public List<PurchaseInvoices> getPurchaseInvoicesByStoreId(Stores storeId) {

        return purchaseInvoicesRepository.findByStoreIdId(storeId);
    }

    @Override
    public List<PurchaseInvoices> getPurchaseInvoicesByVendorId(Vendors vendorId) {

        return purchaseInvoicesRepository.findByVendor(vendorId);
    }

    @Override
    public List<PurchaseInvoices> getBetweenDatesByPIs(String fromDate, String toDate) {
        Date fDate = Date.valueOf(fromDate);
        Date tDate = Date.valueOf(toDate);

        return purchaseInvoicesRepository.findByInvoiceDateBetween(fDate, tDate);
    }

    @Autowired
    private VendorPaymentsRepository vendorPaymentsRepository;
    @Autowired
    private CashBankAccountRepository cashBankAccountRepository;
    @Autowired
    private AccountsLogRepository accountsLogRepository;

    @Override
    public ServiceStatus saveVendorPayments(VendorPaymentsRequest vendorPaymentsRequest) {
        ServiceStatus ss = new ServiceStatus();
        try {
            PurchaseInvoices pii = purchaseInvoicesRepository.findById(vendorPaymentsRequest.getInvoiceId().getId())
                    .get();
            pii.setDueAmount(pii.getDueAmount() - vendorPaymentsRequest.getPaidAmount());
            pii.setPaidAmount(vendorPaymentsRequest.getPaidAmount());
            pii.setModifiedDate(vendorPaymentsRequest.getPaymentDate());
            purchaseInvoicesRepository.save(pii);

            VendorPayments vp = new VendorPayments();
            vp.setInvoiceId(vendorPaymentsRequest.getInvoiceId());
            vp.setAmount(vendorPaymentsRequest.getPaidAmount());
            vp.setPaymentDate(vendorPaymentsRequest.getPaymentDate());
            PurchaseInvoices pi = purchaseInvoicesRepository.getById(vendorPaymentsRequest.getInvoiceId().getId());
            vp.setCreatedBy(new Users().builder().id(pi.getCreatedBy().getId()).build());
            vp.setCreatedDate(vendorPaymentsRequest.getPaymentDate());
            vp.setModeId(vendorPaymentsRequest.getModeId());

            vendorPaymentsRepository.save(vp);
            AccountsLog al = new AccountsLog();
            al.setAmount(vendorPaymentsRequest.getPaidAmount());
            al.setTransactionType("Debit");
            al.setTransactionDate(vendorPaymentsRequest.getPaymentDate());
            long id = 1;
            CashBankAccount cba = cashBankAccountRepository.getById(id);
            al.setBalance(cba.getAmount() - vendorPaymentsRequest.getPaidAmount());
            accountsLogRepository.save(al);
            cba.setAmount(cba.getAmount() - vendorPaymentsRequest.getPaidAmount());
            cashBankAccountRepository.save(cba);
            ss.setStatuesCode("200");
            ss.setMessage("sucsses");
        } catch (ELException e) {
            ss.setStatuesCode("0");
            ss.setMessage("errer" + e);
        }

        return ss;
    }

    @Override
    public List<VendorPayments> getAllVendorPayments(VendorPayments vendorPayments) {

        return vendorPaymentsRepository.findAll();
    }

    @Override
    public VendorPayments getVendorPaymentsById(long id) {

        return vendorPaymentsRepository.findById(id).get();
    }

    @Override
    public List<VendorPayments> getVendorPaymentsByInvoiceId(long invoiceId) {

        return vendorPaymentsRepository.findByInvoiceId(new PurchaseInvoices().builder().id(invoiceId).build());
    }

}
