package com.example.mg_project.request.salesrequest;

import com.example.mg_project.entity.Areas;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SalesOrderAddressRequest {

    private String address;
private String pincode;
private Areas areaId;
private String latitude;
private String longitude;
    
}
