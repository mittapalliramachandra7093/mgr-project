package com.example.mg_project.service;

import java.util.List;

import com.example.mg_project.entity.Areas;
import com.example.mg_project.entity.Cities;
import com.example.mg_project.entity.Country;
import com.example.mg_project.entity.Login;
import com.example.mg_project.entity.States;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.Users;
import com.example.mg_project.servicestatus.ServiceStatus;

import org.springframework.stereotype.Service;

@Service
public interface AdminService 
{

   public  Users saveuser(Users users);
public Users getUserById(long userId);
public List<Users> getUsersByStatus(Boolean status);

public ServiceStatus validatelogin(Login login);

public Country savecountry(Country country);
public Country getCountryById(long countryid);

public States saveStates(States states);
public List<States> allStates();
public List<States> getstatesbycountryid(Country countryId);
public States getStatesById(long statesid);

public Cities saveCitie(Cities cities);
public Cities getCityById(long id);
public List<Cities> allCitys(Cities cities);
public List<Cities> getAllCitysByStatesId(States stateId);


public Areas saveAreas(Areas areas);
public Areas getAreasbyId(long id);
public List<Areas> getAllAreas(Areas areas);
public List<Areas> getAreaByCityId(Cities cityId);
   

public Stores saveStores(Stores stores);
public Stores getStoresById(long id);
public List<Stores> getAllStores(Stores stores);
public Stores getStoresByAreaId(Areas areaId);
public List<Stores> getStoresByPincode(String pincode);

}
