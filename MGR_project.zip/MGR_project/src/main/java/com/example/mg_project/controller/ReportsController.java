package com.example.mg_project.controller;

import java.util.List;

import com.example.mg_project.entity.AccountsLog;
import com.example.mg_project.entity.PurchaseInvoices;
import com.example.mg_project.entity.SalesInvoices;
import com.example.mg_project.entity.Stock;
import com.example.mg_project.response.DuePaymentsResponse;
import com.example.mg_project.response.DueReceipts;
import com.example.mg_project.response.HighestCustomerSales;
import com.example.mg_project.response.Highestsoldproducts;
import com.example.mg_project.response.Reorderlevelreports;
import com.example.mg_project.service.ReportsService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;



@Controller
@RequestMapping("/reports")
public class ReportsController {

    @Autowired
    private ReportsService reportsService;
//Daily Sales Report
@ResponseBody
@GetMapping("/getdailysales/{date}")
private List<SalesInvoices> GetDailySales(@PathVariable("date")   String invoiceDate)
{
    System.out.println("controller stare------------");
   
    reportsService.GetDailySales(invoiceDate);
    System.out.println("return controller");
    return  null;

}

//Daily Purchase Report 
@ResponseBody   
    @GetMapping("/getdailypurchases/{date}")
   private List<PurchaseInvoices> GetDailyPurchasesInvoices(@PathVariable("date")  String  invoiceDate)
   {
       return reportsService.GetDailyPurchasesInvoices(invoiceDate);
   }
// Store Wise Stock Report  

@ResponseBody
   @GetMapping("/getstorewisestock/{id}")
   private List<Stock> GetStorewiseStock(@PathVariable("id") long storeId)
   {
       return reportsService.GetStorewiseStock(storeId);
   }
// Due Payments

   @GetMapping("/getduepayments")
   private String GetDuePayments(Model model)
   {
       List<DuePaymentsResponse> dprlist=reportsService.GetDuePayments();
       model.addAttribute("dpr",dprlist);
       return "DuePayments";
   }
//Due Receipts  
   @GetMapping("/getduereceipts")
   public String getDuereceipts(Model model) 
   {
       List<DueReceipts> drlist= reportsService.getDuereceipts();
      model.addAttribute("dr",drlist);
       return "AllDuereceipts";
   }
//  Highest Sold Products (10 records) 

   @GetMapping("/gethighestsolditems")
   public String getHighestSoldItems(Model model)
   {
       List<Highestsoldproducts> hsilist= reportsService.getHighestSoldItems();
       model.addAttribute("hsi",hsilist);
       return "Highestsoldproducts";
   }

  // Highest Customer Sales (10 records of Customers with number of sales qty and total amount)

  @GetMapping("/gethighestcustomersales")
  public String highestCustomerSales(ModelMap model)
  {
     List<HighestCustomerSales> hcslist=reportsService.highestCustomerSales();
     model.addAttribute("hcs",hcslist);
     return "HighestCustomerSales";
  }

  // Reorder Level Reports

  @GetMapping("/getreorderlevelitems")
  public ModelAndView  getReorderlevelItems(ModelAndView model)
  {
    List<Reorderlevelreports> rolilist= reportsService.getReorderlevelItems();
    model.addObject("roli", rolilist);
     //return "Reorderlevelitems" ;
     model.setViewName("Reorderlevelitems");

     return model;

  }



 //  Accounts Reports

   @GetMapping("/getaccounts")
   private String getAccounts(Model model)
   {
     List<AccountsLog> drlist= reportsService.getAllAccountsLog();
    model.addAttribute("acc",drlist);

        return "Getaccounts";
   }

































 // @GetMapping("getreorderlevelitems")
  // private List<Item> 
   



    
}
