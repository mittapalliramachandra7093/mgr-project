package com.example.mg_project.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class LogisticExpenses {
    @Id
    private Long id;
    @ManyToOne
private SalesOrder soId;
private Double distance;
private Double charges;

    
}
