package com.example.mg_project.request.salesrequest;

import java.util.Date;
import java.util.List;

import com.example.mg_project.entity.SalesOrder;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DeliveryNotesReguest {

    private SalesOrder soId;
    private Date deliveryDate;
    List<DeliveryNoteItemsRequest> dnir;
    DeliveryChargesRequest dcr;

    
}
