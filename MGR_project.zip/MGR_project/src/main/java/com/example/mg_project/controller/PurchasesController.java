package com.example.mg_project.controller;

import java.util.List;

import com.example.mg_project.entity.GoodsReceivedNoteItems;
import com.example.mg_project.entity.GoodsReceivedNotes;
import com.example.mg_project.entity.PurchaseInvoices;
import com.example.mg_project.entity.PurchaseOrderItems;
import com.example.mg_project.entity.PurchaseOrders;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.VendorItems;
import com.example.mg_project.entity.VendorPayments;
import com.example.mg_project.entity.Vendors;
import com.example.mg_project.request.purchaserequest.GrnRequest;
import com.example.mg_project.request.purchaserequest.PurchaseInvoicesRequest;
import com.example.mg_project.request.purchaserequest.PurchaseOrdersRequest;
import com.example.mg_project.request.purchaserequest.VendorPaymentsRequest;
import com.example.mg_project.service.PurchasesService;
import com.example.mg_project.servicestatus.ServiceStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/purchases")
public class PurchasesController {

//vendors
    @Autowired
    private PurchasesService purchasesService;

    @PostMapping("savevendor")
    public Vendors saveVendors(@RequestBody Vendors vendors)
    {
        return purchasesService.saveVendors(vendors);
    }
    @GetMapping("/getvendors")
    public List<Vendors> getvenders(Vendors vendors)
    {
        return purchasesService.getVenders(vendors);
    }
    @GetMapping("/getvendorsbyid/{id}")
    public Vendors getvendorsbyid(@PathVariable("id") long id)
    {
        return purchasesService.getVendersById(id);
    }
// vendor items
    @PostMapping("/savevendoritems")
    public VendorItems saveVendorsItems(@RequestBody VendorItems vendoriItems)
    {
        return purchasesService.saveVendorsItems(vendoriItems);
    }
    @GetMapping("/getvitemsbyvid/{id}")// get vendoritems by vendor id
        public List<VendorItems> getVendorsItemsbyVenderid(@PathVariable("id")long  vendorId)
        {
            return purchasesService.getVendorsItemsByVenderId(vendorId);
        }
// purchase orders

    @PostMapping("/savepurchaseorders")
    public ServiceStatus savePurchaseOrders(@RequestBody PurchaseOrdersRequest por)
    {
        return purchasesService.savePurchaseOrders(por);
    }
    @GetMapping("/getpurchaseorders")//Get all Purchase Orders
    public List<PurchaseOrders> getAllPurchaseOrders(PurchaseOrders purchaseOrders)
    {
        return purchasesService.getAllPurchaseOrders(purchaseOrders);
    }

    @GetMapping("/getpurchaseorders/{fromDate}/{toDate}")//Get Between Purchase Orders
    public List<PurchaseOrders> GetBetweenPurchaseOrders (@PathVariable String fromDate,@PathVariable String toDate)
    {
      return purchasesService.GetBetweenPurchaseOrders(fromDate,toDate);
    }

    @GetMapping("/getpurchaseordersbystoreid/{id}")//Get Purchases Orders By StoreId
    public  List<PurchaseOrders> GetPurchasesOrdersByStoreId(@PathVariable("id") long storeId)
    {
        return purchasesService.GetPurchasesOrdersByStoreId(storeId);
    }
   @GetMapping("/getpurchaseorderbyid/{id}")//Get Purchase Order By Id
    public PurchaseOrders getPurchaseOrderById(@PathVariable("id") long id)
    {
        return purchasesService.getPurchaseOrderById(id);
    }
    @GetMapping("/getposbyvendorid/{id}")//Get Purchase Orders by Vendor Id
    public List<PurchaseOrders> getPurchaseOrdersbyVendorId(@PathVariable("id") long vendorId)
    {
        return purchasesService.getPurchaseOrdersbyVendorId(vendorId);
    }

//purchaseordersItems

@GetMapping("/getpoitemsbypoid/{id}")//Get PurchaseOrderItems by PO Id
public List<PurchaseOrderItems> getPurchaseOrderItemsbyPOId(@PathVariable("id") long id)
{
    return purchasesService.getPurchaseOrderItemsbyPOId(id);
}


//GoodsReceivedNotes
@PostMapping("/savegrn")//Save Goods Received Notes
public ServiceStatus saveGrn(@RequestBody GrnRequest grnRequest)
{
    return purchasesService.saveGrn(grnRequest);
}

@GetMapping("/getgrns")//Get All GRN
public List< GoodsReceivedNotes> getAllGRN(GoodsReceivedNotes goodsReceivedNotes)
{
    return purchasesService.getAllGRN(goodsReceivedNotes);
}

@GetMapping("/getgrnbyid/{id}")//Get GRN By Id
public GoodsReceivedNotes getGRNById(@PathVariable long id)
{
    return purchasesService.getGRNById(id);
}

@GetMapping("/getgrns/{fromDate}/{toDate}")//Get Between GRNs
public  List< GoodsReceivedNotes> getBetweenGRNs(@PathVariable String fromDate,@PathVariable String toDate)
{
    return purchasesService.getBetweenDatesByGRNs(fromDate,toDate);
}

@GetMapping("/getgrnbystoreid/{id}")//Get GRN By Store Id
public List< GoodsReceivedNotes> getGRNByStoreId(@PathVariable("id") Stores storeId)
{
    return purchasesService.getGRNByStoreId(storeId);
}

@GetMapping("/getgrnbyvendorid/{id}")//Get GRN By Vendor Id
public List< GoodsReceivedNotes >getGRNByVendorId(@PathVariable("id") Vendors vendor)
{
    return purchasesService.etGRNByVendorId(vendor);
}

@GetMapping("/getgrnitemsbygrnid/{id}")//Get GRN Items by GRN Id
public GoodsReceivedNoteItems  getGRNItemsbyGRNId(@PathVariable("id") GoodsReceivedNotes grnId)
{
    return purchasesService.getGRNItemsbyGRNId(grnId);
}

//PurchaseInvoices


@PostMapping("/savepurchaseinvoice")
public ServiceStatus savePurchaseInvoices(@RequestBody PurchaseInvoicesRequest pir)
{
    return purchasesService.savePurchaseInvoices(pir);
}
@GetMapping("/getpurchaseinvoices")
public List<PurchaseInvoices> getAllPurchaseInvoices(PurchaseInvoices purchaseInvoices)
{
    return purchasesService.getAllPurchaseInvoices(purchaseInvoices);
}
@GetMapping("/getpibyid/{id}")
public PurchaseInvoices getPurchaseInvoicesById(@PathVariable("id") long id)
{
     return purchasesService.getPurchaseInvoicesById(id);
 }
/*@GetMapping("/getpibystoreid/{id}")
public List<PurchaseInvoices> getPurchaseInvoicesByStoreId(@PathVariable("id") Stores storeId)
{
     return purchasesService.getPurchaseInvoicesByStoreId(storeId);
 }*/

@GetMapping("/getpibyvendorid/{id}")
public List<PurchaseInvoices> getPurchaseInvoicesByVendorId(@PathVariable("id") Vendors vendorId)
{
     return purchasesService.getPurchaseInvoicesByVendorId(vendorId);
 }

@GetMapping("/getpurchaseinvoices/{fromDate}/{toDate}")
public  List< PurchaseInvoices> getBetweenPIs(@PathVariable String fromDate,@PathVariable String toDate)
{
    return purchasesService.getBetweenDatesByPIs(fromDate,toDate);
}
//VendorPayments

@PostMapping("/savevendorpayment")
public ServiceStatus saveVendorPayments(@RequestBody VendorPaymentsRequest vendorPaymentsRequest)
{
    return purchasesService.saveVendorPayments(vendorPaymentsRequest);
}


@GetMapping("/getvendorpayments")
public List<VendorPayments> getAllVendorPayments(VendorPayments vendorPayments)
{
    return purchasesService.getAllVendorPayments(vendorPayments);
}

@GetMapping("/getvendorpayments/{id}")
public VendorPayments getVendorPaymentsById(@PathVariable("id") long id)
{
     return purchasesService.getVendorPaymentsById(id);
 }

@GetMapping("/getvpbyinvoiceid/{id}")
public List< VendorPayments> getVendorPaymentsByInvoiceId(@PathVariable("id") long invoiceId)
{
     return purchasesService.getVendorPaymentsByInvoiceId(invoiceId);
 }



}
