package com.example.mg_project.reposiory.purchasesrepository;

import java.util.List;

import com.example.mg_project.entity.GoodsReceivedNoteItems;
import com.example.mg_project.entity.GoodsReceivedNotes;
import com.example.mg_project.entity.Items;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface GoodsReceivedNoteItemsRepository extends JpaRepository<GoodsReceivedNoteItems,Long>
{

   // GoodsReceivedNoteItems findByGrnId(GoodsReceivedNotes grnId);

    GoodsReceivedNoteItems findByItemId(Items build);

    List<GoodsReceivedNoteItems> findByGrnId(GoodsReceivedNotes build);

    GoodsReceivedNoteItems findByGrnIdAndItemId(Long id, long itemId);

    GoodsReceivedNoteItems findByGrnIdAndItemId(GoodsReceivedNotes build, Items build2);
    
}
