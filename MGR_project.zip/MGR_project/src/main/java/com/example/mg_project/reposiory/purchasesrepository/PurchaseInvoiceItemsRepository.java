package com.example.mg_project.reposiory.purchasesrepository;

import com.example.mg_project.entity.PurchaseInvoiceItems;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface PurchaseInvoiceItemsRepository extends JpaRepository<PurchaseInvoiceItems,Long>
{
    
}
