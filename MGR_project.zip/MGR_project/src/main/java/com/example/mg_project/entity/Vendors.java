package com.example.mg_project.entity;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
//import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Vendors {
    @Id
    private Long id;
private String vendorName;
private String mobile;
private String email;
@ManyToOne
private Areas areaId;
private String pincode;
private Date createdDate;
@OneToOne
private Users createdBy;
private Date modifiedDate;
@OneToOne
private Users modifiedBy;
}
