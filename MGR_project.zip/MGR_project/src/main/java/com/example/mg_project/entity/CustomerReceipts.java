package com.example.mg_project.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CustomerReceipts {
    @Id
    @GeneratedValue
    private Long id;
@OneToOne
private SalesInvoices invoiceId;
private Double amount;
private Date paymentDate;
private Date createdDate;
@ManyToOne
private Users createdBy;
@ManyToOne
private PaymentModes modeId;

}
