package com.example.mg_project.service;


import java.util.List;

import com.example.mg_project.entity.GoodsReceivedNoteItems;
import com.example.mg_project.entity.GoodsReceivedNotes;
import com.example.mg_project.entity.PurchaseInvoices;
import com.example.mg_project.entity.PurchaseOrderItems;
import com.example.mg_project.entity.PurchaseOrders;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.VendorItems;
import com.example.mg_project.entity.VendorPayments;
import com.example.mg_project.entity.Vendors;
import com.example.mg_project.request.purchaserequest.GrnRequest;
import com.example.mg_project.request.purchaserequest.PurchaseInvoicesRequest;
import com.example.mg_project.request.purchaserequest.PurchaseOrdersRequest;
import com.example.mg_project.request.purchaserequest.VendorPaymentsRequest;
import com.example.mg_project.servicestatus.ServiceStatus;


public interface PurchasesService 
{

Vendors saveVendors(Vendors vendors);

List<Vendors> getVenders(Vendors vendors);

Vendors getVendersById(long id);

VendorItems saveVendorsItems(VendorItems vendoriItems);

List< VendorItems> getVendorsItemsByVenderId(long vendorId);

ServiceStatus savePurchaseOrders(PurchaseOrdersRequest por);

List<PurchaseOrders> getAllPurchaseOrders(PurchaseOrders purchaseOrders);

List<PurchaseOrders> GetBetweenPurchaseOrders(String fromDate, String toDate);

List<PurchaseOrders> GetPurchasesOrdersByStoreId(long storeId);

PurchaseOrders getPurchaseOrderById(long id);

List<PurchaseOrders> getPurchaseOrdersbyVendorId(long vendorId);
    
List<PurchaseOrderItems> getPurchaseOrderItemsbyPOId(long id);

ServiceStatus saveGrn(GrnRequest grnRequest);

List<GoodsReceivedNotes> getAllGRN(GoodsReceivedNotes goodsReceivedNotes);

GoodsReceivedNotes getGRNById(long id);

List<GoodsReceivedNotes> getBetweenDatesByGRNs(String fromDate, String toDate);

List<GoodsReceivedNotes> getGRNByStoreId(Stores storeId);

List< GoodsReceivedNotes >etGRNByVendorId(Vendors vendor);

GoodsReceivedNoteItems getGRNItemsbyGRNId(GoodsReceivedNotes grnId);

ServiceStatus savePurchaseInvoices(PurchaseInvoicesRequest pir);

List<PurchaseInvoices> getAllPurchaseInvoices(PurchaseInvoices purchaseInvoices);

PurchaseInvoices getPurchaseInvoicesById(long id);

List<PurchaseInvoices> getPurchaseInvoicesByStoreId(Stores storeId);

List<PurchaseInvoices> getPurchaseInvoicesByVendorId(Vendors vendorId);

List<PurchaseInvoices> getBetweenDatesByPIs(String fromDate, String toDate);

ServiceStatus saveVendorPayments(VendorPaymentsRequest vendorPaymentsRequest);

List<VendorPayments> getAllVendorPayments(VendorPayments vendorPayments);

VendorPayments getVendorPaymentsById(long id);

List<VendorPayments> getVendorPaymentsByInvoiceId(long invoiceId);



}
