package com.example.mg_project.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
//import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Stock {
    @Id
    private Long id;
  
private long quantity;
private long reorderLevel;
private long overflowLevel;
@ManyToOne
private Stores storeId;
@ManyToOne
private Items itemId;
}
