package com.example.mg_project.reposiory.purchasesrepository;

import java.util.List;

import com.example.mg_project.entity.PurchaseOrderItems;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

@Repository
public interface PurchaseOrderItemsRepository extends JpaRepository<PurchaseOrderItems,Long>
{

    List<PurchaseOrderItems> findByPoIdId(long id);

    
    
}
