package com.example.mg_project.service;

import java.util.List;

import com.example.mg_project.entity.Category;
import com.example.mg_project.entity.Items;
import com.example.mg_project.entity.Stock;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.UOM;
import com.example.mg_project.reposiory.inventoryrepository.CategoryRepository;
import com.example.mg_project.reposiory.inventoryrepository.ItemsRepository;
import com.example.mg_project.reposiory.inventoryrepository.StockRepository;
import com.example.mg_project.reposiory.inventoryrepository.UomRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InventoryServiceImpl implements InventoryService
{
@Autowired
private CategoryRepository categoryRepository;
    @Override
    public Category saveCategory(Category category) {
        
        return categoryRepository.save(category);
    }
    @Override
    public List<Category> allCategory(Category category) {
        
        return categoryRepository.findAll();
    }
    @Override
    public Category getCategoryById(long id) {
    
        return categoryRepository.findById(id).get();
    }


@Autowired
private UomRepository uomRepository;
    @Override
    public List<UOM> getAllUom(UOM uom) {
        
        return uomRepository.findAll();
    }
    @Override
    public UOM getUomById(long id) {
        
        return uomRepository.findById(id).get();
    }

@Autowired
private ItemsRepository itemsRepository;
    @Override
    public Items saveItems(Items items) {
        
        return itemsRepository.save(items);
    }
    @Override
    public Items getItemsById(long id) {
        
        return itemsRepository.findById(id).get();
    }
    @Override
    public List<Items> getAllItems(Items items) {
        
        return itemsRepository.findAll();
    }
@Autowired
private StockRepository stockRepository;

    @Override
    public Stock saveStock(Stock stock) {
    
        return stockRepository.save(stock);
    }
    @Override
    public Stock getStockByItemId(Items itemId) {
        
        return stockRepository.findByItemId(itemId);
    }
    @Override
    public List<Stock> getAllStock(Stock stock) {
        
        return stockRepository.findAll();
    }
    @Override
    public List<Stock> getStockByStoreId(long storeId) {
    
        return stockRepository.findByStoreId(new Stores().builder().id(storeId).build());
    }
    




    
}
