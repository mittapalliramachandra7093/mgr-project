package com.example.mg_project.service;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.example.mg_project.entity.AccountsLog;
import com.example.mg_project.entity.Customers;
import com.example.mg_project.entity.Items;
import com.example.mg_project.entity.PurchaseInvoices;
import com.example.mg_project.entity.SalesInvoices;
import com.example.mg_project.entity.SalesOrderItems;
import com.example.mg_project.entity.Stock;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.Vendors;
import com.example.mg_project.reposiory.adminRepository.StoresRepository;
import com.example.mg_project.reposiory.inventoryrepository.AccountsLogRepository;
import com.example.mg_project.reposiory.inventoryrepository.ItemsRepository;
import com.example.mg_project.reposiory.inventoryrepository.StockRepository;
import com.example.mg_project.reposiory.purchasesrepository.PurchaseInvoicesRepository;
import com.example.mg_project.reposiory.purchasesrepository.VendorsRepository;
import com.example.mg_project.reposiory.salesrepository.CustomersRepository;
import com.example.mg_project.reposiory.salesrepository.SalesInvoicesRepository;
import com.example.mg_project.reposiory.salesrepository.SalesOrderItemsRepository;
import com.example.mg_project.reposiory.salesrepository.SalesOrdersRepository;
import com.example.mg_project.response.DuePaymentsResponse;
import com.example.mg_project.response.DueReceipts;
import com.example.mg_project.response.HighestCustomerSales;
import com.example.mg_project.response.Highestsoldproducts;
import com.example.mg_project.response.Reorderlevelreports;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class ReportsServiceImpl implements ReportsService 
{
    @Autowired
    private SalesInvoicesRepository salesInvoicesRepository;

    @Override
    public List<SalesInvoices> GetDailySales(String invoiceDate) {
                
        Date date=Date.valueOf(invoiceDate);

        //List<SalesInvoices> silist=salesInvoicesRepository.findByInvoiceDate(date);

        System.out.println("date " + date);
        String startDate = invoiceDate + " 00:00:00";
        String endDate = invoiceDate + " 23:59:59";

        List<SalesInvoices> silist=salesInvoicesRepository.findByInvoiceDateCustom(startDate, endDate);


        return silist;
    }

    @Autowired
    private PurchaseInvoicesRepository purchaseInvoicesRepository;
    @Override
    public List<PurchaseInvoices> GetDailyPurchasesInvoices(String invoiceDate) {
        Date date=Date.valueOf(invoiceDate);
        return purchaseInvoicesRepository.findByInvoiceDate(date);
    }


    @Autowired
    private StockRepository stockRepository;
    @Override
    public List<Stock> GetStorewiseStock(long storeId) {
    
        return stockRepository.findByStoreId(new Stores().builder().id(storeId).build());
    }

    
    @Autowired
    private VendorsRepository vendorsRepostory;
    @Override
    public List<DuePaymentsResponse> GetDuePayments() {
    
        List<PurchaseInvoices> pilist=purchaseInvoicesRepository.findAll();

        List<DuePaymentsResponse> piarray=new ArrayList<>();
        for(int i=0;i<pilist.size();i++)
        {
            PurchaseInvoices pi=purchaseInvoicesRepository.getById(pilist.get(i).getId());
            if(pi.getDueAmount()>0)
            {
                DuePaymentsResponse dpr=new DuePaymentsResponse();
                dpr.setDueAmount(pi.getDueAmount());
                dpr.setInvoiceAmount(pi.getInvoiceAmount());
                dpr.setPaidAmount(pi.getPaidAmount());
                dpr.setInvoiceNumber(pi.getInvoiceNo());
                dpr.setInvoiceDate(pi.getInvoiceDate());
                Vendors v=vendorsRepostory.getById(pi.getVendor().getId());
                dpr.setVendorName(v.getVendorName());

                piarray.add(dpr);
            }
        }

        return piarray;
    }
@Autowired
private CustomersRepository customersRepository;
    @Override
    public List<DueReceipts> getDuereceipts() {
        
            List<SalesInvoices> silist=salesInvoicesRepository.findAll();

        List<DueReceipts> siarray=new ArrayList<>();

        for(int i=0;i<silist.size();i++)
        {
           
            SalesInvoices si=salesInvoicesRepository.getById(silist.get(i).getId());
            if(si.getDueAmount()>0)
            {
                DueReceipts dr=new DueReceipts();
                Customers c=customersRepository.getById(si.getCustomer().getId());
                dr.setCustomerName(c.getCustomerName());
                dr.setDue(si.getDueAmount());
                dr.setInvoiceAmount(si.getInvoiceAmount());
                dr.setInvoiceDate(si.getInvoiceDate());
                dr.setInvoiceNumber(si.getInvoiceNo());
                dr.setPaid(si.getPaidAmount());
                siarray.add(dr);
            }
        }
 
        return siarray;  
        
    }

    @Autowired
    private SalesOrderItemsRepository salesOrderItemsRepository;
    @Autowired 
    private ItemsRepository itemsRepository;
    @Override
    public List<Highestsoldproducts> getHighestSoldItems() 
    {
       
         List<Items> ilist=itemsRepository.findAll();
       Map<Integer,Integer>  m= new HashMap<Integer,Integer>();
        for(int i=0;i<ilist.size();i++)
        {
            List<SalesOrderItems> soilist=salesOrderItemsRepository.findByItemId(new Items().builder().id(ilist.get(i).getId()).build());
            Integer quantity=0;
            for(int j=0;j<soilist.size();j++)
            {
                try{

                 SalesOrderItems soi=salesOrderItemsRepository.findById(soilist.get(j).getId()).get();
                 quantity+=soi.getQuantity();

                }
                catch(Exception e)
                {
                System.out.println(e);
                }
            }
            m.put(ilist.get(i).getId().intValue(),quantity);
           // System.out.println(ilist.get(i).getId()+"--------"+quantity);
        }

//System.out.println(m);
// Create a list from elements of HashMap
List<Map.Entry<Integer, Integer> > list =new LinkedList<Map.Entry<Integer, Integer> >(m.entrySet());

// Sort the list
Collections.sort(list, new Comparator<Map.Entry<Integer,Integer> >()
 {
    public int compare(Map.Entry<Integer, Integer> o1,
                       Map.Entry<Integer, Integer> o2)
    {
        return (o1.getValue()).compareTo(o2.getValue());
    }
});


List<Highestsoldproducts> hsplist=new ArrayList<>();

for(int i=list.size()-1;i>=0;i--)
{
Highestsoldproducts hsp=new Highestsoldproducts();
Items items=itemsRepository.findById(list.get(i).getKey().longValue()).get();
hsp.setItemCode(items.getItemCode());
hsp.setItemName(items.getItemName());
hsp.setQuantity(list.get(i).getValue());
hsplist.add(hsp);
}
        return hsplist;
    }

    @Autowired
    private SalesOrdersRepository salesOrderRepository;
@Override
public List<HighestCustomerSales> highestCustomerSales() {
    // find list of costamars
     Set<Long> s=new HashSet<>();
     List<SalesInvoices> allsi=salesInvoicesRepository.findAll();
     for(int i=0;i<allsi.size();i++)
     {
         s.add(allsi.get(i).getCustomer().getId());
     }
     List<Long> listofcostamars=new ArrayList<>();
     listofcostamars.addAll(s);
//find highest- using order amount
      Map<Long,Integer>  m=new HashMap();
      Map<Long,Double>  n=new HashMap();

      for(int i=0;i<s.size();i++) 
      { 
       List<SalesInvoices> silist=salesInvoicesRepository.findByCustomer(new Customers().builder().id(listofcostamars.get(i)).build());
       Double amount=0.0;
       for(int j=0;j<silist.size();j++)
       {
           SalesInvoices si=salesInvoicesRepository.getById(silist.get(j).getId());
          amount+=si.getInvoiceAmount();
       }
      //   System.out.println("c no--"+listofcostamars.get(i)+"  c o = "+silist.size()+" t amount= "+amount);
     m.put(listofcostamars.get(i), silist.size()); n.put(listofcostamars.get(i), amount);
      }
      
                List<Map.Entry<Long,Double> > hcslist =
            new LinkedList<Map.Entry<Long,Double> >(n.entrySet());
            // Sort the list
            Collections.sort(hcslist, new Comparator<Map.Entry<Long,Double> >() {
            public int compare(Map.Entry<Long,Double> o1,
                            Map.Entry<Long,Double> o2)
            {
            return (o1.getValue()).compareTo(o2.getValue());
            }
            });
          List<HighestCustomerSales> hcsretanlist= new ArrayList<>();
    for(int i=hcslist.size()-1;i>=0;i--)
    {
        HighestCustomerSales hcs=new HighestCustomerSales();
        Customers c=customersRepository.findById(hcslist.get(i).getKey()).get();
        hcs.setCustomerName(c.getCustomerName());
       hcs.setMobile(c.getMobile());
       hcs.setTimesOrdered(m.get(hcslist.get(i).getKey()));
       hcs.setTotalAmount(hcslist.get(i).getValue());

       hcsretanlist.add(hcs);
    }

        return hcsretanlist;
    }




@Autowired
private StoresRepository storesRepository;
    @Override
    public List<Reorderlevelreports> getReorderlevelItems() {

        List<Stock> stocks=stockRepository.findAll();
        List<Reorderlevelreports> rolilist=new ArrayList<>();
        for(int i=0;i<stocks.size();i++)
        {
           // System.out.println("id-->"+stocks.get(i).getId()+"   q-->"+stocks.get(i).getQuantity()+"   ro-->"+stocks.get(i).getReorderLevel()+" ofl--->"+stocks.get(i).getOverflowLevel());
            if(stocks.get(i).getQuantity()<=stocks.get(i).getReorderLevel())
            {
                
                Reorderlevelreports roli=new Reorderlevelreports();
                Stores stores=storesRepository.getById(stocks.get(i).getStoreId().getId());
                roli.setStoreName(stores.getStoreName());
                Items items=itemsRepository.getById(stocks.get(i).getItemId().getId());
                roli.setItemName(items.getItemName());
                roli.setQty(stocks.get(i).getQuantity());
                roli.setReorder(stocks.get(i).getReorderLevel());
                roli.setOverflow(stocks.get(i).getOverflowLevel());
                rolilist.add(roli);

            }

        }   
        return rolilist;
    }
    @Autowired
    private AccountsLogRepository accountsLogRepository;
    @Override
    public List<AccountsLog> getAllAccountsLog() {
        
        return accountsLogRepository.findAll();
    }
   
    


    
}
