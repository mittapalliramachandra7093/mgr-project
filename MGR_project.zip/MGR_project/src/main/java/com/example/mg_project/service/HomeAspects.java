/*package com.example.mg_project.service;

import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class HomeAspects {

@Pointcut("execution( public String com.example.mg_project.controller.frent_end_controller.HomeController .home())")
    public void pl(){}


    @Before("pl()")
    public String b()
    {
        return "Login";
    }
    @After("pl()")
    public void a()
    {
        System.out.println("affter succ msg");
    }
    
}*/
