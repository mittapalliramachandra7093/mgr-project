package com.example.mg_project.controller;

import java.util.List;

import com.example.mg_project.entity.Category;
import com.example.mg_project.entity.Items;
import com.example.mg_project.entity.Stock;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.UOM;
import com.example.mg_project.service.InventoryService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;


@Controller
@RequestMapping("/inventory")
public class InventoryController {

@Autowired
private InventoryService inventoryService;

//category
    @PostMapping("/savecategory")
    public Category saveCategory(@RequestBody Category category)
    {
        return inventoryService.saveCategory(category);
    }
    @ResponseBody
    @GetMapping("/getcategorys")
    public List<Category> allCategory(Category category)
    {
        return inventoryService.allCategory(category);
    }
    @ResponseBody
    @GetMapping("/getcategorybyid/{id}")
    public Category getCategoryById(@PathVariable("id") long id)
    {
        return inventoryService.getCategoryById(id);
    }
//uom
@ResponseBody
@GetMapping("/getuoms")
public List<UOM> getAllUoms(UOM uom)
{
    return inventoryService.getAllUom(uom);
}
@ResponseBody
@GetMapping("/getuombyid/{id}")
public UOM getUomById(@PathVariable("id") long id)
{
    return inventoryService.getUomById(id);
}
//iteams
@PostMapping("/saveitems")
public Items saveItems(@RequestBody Items items)
{
    return inventoryService.saveItems(items);
}
@ResponseBody
@GetMapping("/getitemsbyid/{id}")
public Items getItemsById(@PathVariable("id") long id)
{
    return inventoryService.getItemsById(id);
}
@ResponseBody
@GetMapping("/getitems")
public List<Items> getAllItems(Items items)
{
    return inventoryService.getAllItems(items);
}
//stock
@PostMapping("/savestock")
public Stock saveStock(@RequestBody Stock stock)
{
    return inventoryService.saveStock(stock);
}
@ResponseBody
@GetMapping("/getstockbyitemid/{itemid}")
public Stock getStockByItemId(@PathVariable("itemid") Items itemId)
{
    return inventoryService.getStockByItemId(itemId);
}
@ResponseBody
@GetMapping("/getallstock")
public List<Stock> getAllStock(Stock stock)
{
    return inventoryService.getAllStock(stock);
}
@ResponseBody
@GetMapping("/getstockbystoreid/{storeid}")
public List<Stock> getStockByStoreId(@PathVariable("storeid") long storeId)
{
    return inventoryService.getStockByStoreId(storeId);
}

}
