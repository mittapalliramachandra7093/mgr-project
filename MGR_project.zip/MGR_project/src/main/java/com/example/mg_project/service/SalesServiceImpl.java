package com.example.mg_project.service;


import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import com.example.mg_project.entity.AccountsLog;
import com.example.mg_project.entity.CashBankAccount;
import com.example.mg_project.entity.CustomerReceipts;
import com.example.mg_project.entity.Customers;
import com.example.mg_project.entity.DeliveryCharges;
import com.example.mg_project.entity.DeliveryNoteItems;
import com.example.mg_project.entity.DeliveryNotes;
import com.example.mg_project.entity.Items;
import com.example.mg_project.entity.LogisticExpenses;
import com.example.mg_project.entity.SalesInvoiceItems;
import com.example.mg_project.entity.SalesInvoices;
import com.example.mg_project.entity.SalesOrderAddress;
import com.example.mg_project.entity.SalesOrderItems;
import com.example.mg_project.entity.Stock;
import com.example.mg_project.entity.SalesOrder;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.reposiory.inventoryrepository.AccountsLogRepository;
import com.example.mg_project.reposiory.inventoryrepository.CashBankAccountRepository;
import com.example.mg_project.reposiory.inventoryrepository.ItemsRepository;
import com.example.mg_project.reposiory.inventoryrepository.StockRepository;
import com.example.mg_project.reposiory.salesrepository.CustomerReceiptsRepository;
import com.example.mg_project.reposiory.salesrepository.CustomersRepository;
import com.example.mg_project.reposiory.salesrepository.DeliveryChargesRepository;
import com.example.mg_project.reposiory.salesrepository.DeliveryNoteItemsRepository;
import com.example.mg_project.reposiory.salesrepository.DeliveryNotesRepository;
import com.example.mg_project.reposiory.salesrepository.SalesInvoiceItemsRepository;
import com.example.mg_project.reposiory.salesrepository.SalesInvoicesRepository;
import com.example.mg_project.reposiory.salesrepository.SalesOrderAddressRepository;
import com.example.mg_project.reposiory.salesrepository.SalesOrderItemsRepository;
import com.example.mg_project.reposiory.salesrepository.SalesOrdersRepository;
import com.example.mg_project.request.salesrequest.DeliveryNotesReguest;
import com.example.mg_project.request.salesrequest.SalesInvoicesRequest;
import com.example.mg_project.request.salesrequest.SalesOrdersRequest;
import com.example.mg_project.servicestatus.ServiceStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
public class SalesServiceImpl implements SalesService
{
    @Autowired
    private CustomersRepository customersRepository;

    @Override
    public Customers saveCustomers(Customers customers) {
        
        return customersRepository.save(customers);
    }

    @Override
    public Customers getCustomersById(long id) {
        
        return customersRepository.findById(id).get();
    }

    @Override
    public List<Customers> getAllCustomers(Customers customers) {
        
        return customersRepository.findAll();
    }


@Autowired
private SalesOrdersRepository salesOrdersRepository;
@Autowired
private ItemsRepository itemsRepository;
@Autowired
private SalesOrderItemsRepository salesOrderItemsRepository;
@Autowired
private SalesOrderAddressRepository salesOrderAddressRepository;

    @Override
    public ServiceStatus saveSalesOrders(SalesOrdersRequest salesOrdersRequest) {
        ServiceStatus ss=new ServiceStatus();
     try{   
// SalesOrders
SalesOrder so=new SalesOrder();
Double orderAmount=0.0;
 Integer quantity=0;
so.setOrderDate(salesOrdersRequest.getOrderDate());
so.setOrderAmount(orderAmount);
so.setQuantity(quantity);
so.setCustomer(salesOrdersRequest.getCustomer());
so.setStoreId(salesOrdersRequest.getStoreId());
so.setCreatedDate(salesOrdersRequest.getOrderDate());
so.setCreatedBy(salesOrdersRequest.getCreatedBy());
      
SalesOrder savedso=salesOrdersRepository.save(so);
//so items
        List<SalesOrderItems> soirlist=new ArrayList<SalesOrderItems>();
        for(int i=0;i<salesOrdersRequest.getSoir().size();i++)
        {
            SalesOrderItems soi=new SalesOrderItems();
            Items items=itemsRepository.findById(salesOrdersRequest.getSoir().get(i).getItemId()).get();
            soi.setSoId(new SalesOrder().builder().id(so.getId()).build());
            soi.setItemId(new Items().builder().id(items.getId()).build());
            soi.setQuantity(salesOrdersRequest.getSoir().get(i).getQuantity());
            soi.setRate(items.getMrp());
            soi.setUomId(items.getUomId());
            soi.setSalesPrice(((items.getMrp()*5)/100)*(salesOrdersRequest.getSoir().get(i).getQuantity()));
           soirlist.add(soi);
            orderAmount=orderAmount+(((items.getMrp()*5)/100)*(salesOrdersRequest.getSoir().get(i).getQuantity()));
            quantity=quantity+salesOrdersRequest.getSoir().get(i).getQuantity();
        }
//so address
    SalesOrderAddress soa=new SalesOrderAddress();
    soa.setSoIdId(new SalesOrder().builder().id(so.getId()).build());
    soa.setAddress(salesOrdersRequest.getSoar().getAddress());
    soa.setAreaId(salesOrdersRequest.getSoar().getAreaId());
    soa.setLatitude(salesOrdersRequest.getSoar().getLatitude());
    soa.setLongitude(salesOrdersRequest.getSoar().getLongitude());
    soa.setPincode(salesOrdersRequest.getSoar().getPincode());
    salesOrderAddressRepository.save(soa);
    salesOrderItemsRepository.saveAll(soirlist);
    so.setOrderAmount(orderAmount);
    so.setQuantity(quantity);

    salesOrdersRepository.save(so);
    
ss.setStatuesCode("200");
ss.setMessage("save sales order successfully_______");
    }
    catch(Exception e)
    {
        ss.setStatuesCode("0");
        ss.setMessage("errer  "+e);
    }
        return ss;
    }

    @Override
    public List<SalesOrder> getAllSalesOrders(SalesOrder salesOrders) {
        
        return salesOrdersRepository.findAll();
    }

    @Override
    public SalesOrder getSalesOrdersById(long id) {
        
        return salesOrdersRepository.findById(id).get();
    }

    @Override
    public SalesOrderItems getSoItemsBySoId(SalesOrder soId) {
    
        return null;
    }

    @Override
    public SalesOrderAddress getSalesOrderAddressBySoId(SalesOrder soId) {
        
        return null;
    }

    @Override
    public List<SalesOrder> getBetweenDatesBySalesOrders(String fromDate, String toDate) {
        
        return null;
    }

    @Override
    public LogisticExpenses getLogisticExpensesBySoId(SalesOrder soId) {

        return null;
    }
//DeliveryNotes
@Autowired
private DeliveryNotesRepository deliveryNotesRepository;
@Autowired
private DeliveryNoteItemsRepository deliveryNoteItemsRepository;
@Autowired
private StockRepository stockRepository ;
@Autowired
private DeliveryChargesRepository deliveryChargesRepository;
    @Override
    public ServiceStatus saveDeliveryNotes(DeliveryNotesReguest deliveryNotesReguest) {
        ServiceStatus ss=new ServiceStatus();
        try{
            Integer totalquantity=0;
            DeliveryNotes dn=new DeliveryNotes();
            
        SalesOrder so=salesOrdersRepository.findById(deliveryNotesReguest.getSoId().getId()).get();
       // System.out.println("find so-----------------------");
        dn.setSoId(deliveryNotesReguest.getSoId());
            dn.setCustomer(so.getCustomer());
            dn.setDeliveryDate(deliveryNotesReguest.getDeliveryDate());
            dn.setQuantity(totalquantity);
            dn.setStoreId(so.getStoreId());
            dn.setCreatedDate(deliveryNotesReguest.getDeliveryDate());
            dn.setCreatedBy(so.getCreatedBy());
           // System.out.println("set all--------------------------------------------");
            DeliveryNotes dnsave=deliveryNotesRepository.save(dn);
            System.out.println("save dn------------------");
            List<DeliveryNoteItems> dnilist=new ArrayList<DeliveryNoteItems>();

            for(int i=0;i<deliveryNotesReguest.getDnir().size();i++)
            {
                DeliveryNoteItems dni=new DeliveryNoteItems();
                dni.setDnId(new DeliveryNotes().builder().id(dnsave.getId()).build());
                dni.setItemId(new Items().builder().id(deliveryNotesReguest.getDnir().get(i).getItemId()).build());
                dni.setQuantity(deliveryNotesReguest.getDnir().get(i).getQuantity());
                Items items=itemsRepository.findById(deliveryNotesReguest.getDnir().get(i).getItemId()).get();
                dni.setUomId(items.getUomId());
                dnilist.add(dni);
                totalquantity=totalquantity+deliveryNotesReguest.getDnir().get(i).getQuantity();
            }
deliveryNoteItemsRepository.saveAll(dnilist);
dn.setQuantity(totalquantity);
deliveryNotesRepository.save(dn);
//deliver charge
DeliveryCharges dc=new DeliveryCharges();
dc.setDnId(new DeliveryNotes().builder().id(dnsave.getId()).build());
dc.setDistance(deliveryNotesReguest.getDcr().getDistance());
dc.setCharges(deliveryNotesReguest.getDcr().getCharges());
deliveryChargesRepository.save(dc);
//stock 
List<Stock> stocklist=new ArrayList<Stock>();
int overflowLevel=0;
int reorderLevel=0;
for(int i=0;i<deliveryNotesReguest.getDnir().size();i++)
{
    Stock stockObj=new Stock();
        Stock stock=stockRepository.findByStoreIdAndItemId(new Stores().builder().id(so.getStoreId().getId()).build(),new Items().builder().id(deliveryNotesReguest.getDnir().get(i).getItemId()).build());
        System.out.println(stock);
            stockObj.setId(stock.getId());
            stockObj.setQuantity(stock.getQuantity()-deliveryNotesReguest.getDnir().get(i).getQuantity());
            stockObj.setReorderLevel(reorderLevel);
            stockObj.setOverflowLevel(overflowLevel);
            stockObj.setStoreId(stock.getStoreId());
            stockObj.setItemId(stock.getItemId());
            stocklist.add(stockObj);  
    }
     stockRepository.saveAll(stocklist);

            ss.setStatuesCode("200");
            ss.setMessage(" save deliverynotes & deliverynotesItems & Stock update ");
        }
        catch(Exception e)
        { 
            ss.setStatuesCode("0");
            ss.setMessage("  "+e);
        }

        return ss;
    }

    @Override
    public List<DeliveryNotes> getAllDeliveryNotes(DeliveryNotes deliveryNotes) {
        
        return deliveryNotesRepository.findAll();
    }

    @Override
    public DeliveryNotes getDeliveryNotesById(long id) {
        
        return deliveryNotesRepository.findById(id).get();
    }

    @Override
    public List<DeliveryNoteItems> getDeliveryNotesItemsByDeliveryNotesId(DeliveryNotes dnId) {
        
        return deliveryNoteItemsRepository.findByDnId(dnId);
    }
     

    @Override
    public DeliveryCharges getDeliveryChargesByDeliveryNotesId(DeliveryNotes dnId) {
        
        return deliveryChargesRepository.getByDnId(dnId);
    }
//SalesInvoices
@Autowired
private SalesInvoicesRepository salesInvoicesRepository;
@Autowired 
private SalesInvoiceItemsRepository salesInvoiceItemsRepository;

    @Override
    public ServiceStatus saveSalesInvoices(SalesInvoicesRequest sir) {
        
        ServiceStatus ss=new ServiceStatus();

        try{
            Integer quantity=0;
            Double invoiceAmount=0.0;
            double paidAmount=0.0;

            SalesInvoices si=new SalesInvoices();
            si.setInvoiceNo(sir.getInvoiceNo());
            si.setSoId(sir.getSoId());
            si.setInvoiceDate(sir.getInvoiceDate());
            si.setPaidAmount(paidAmount);
         //by use soid to find so details
           SalesOrder so=salesOrdersRepository.findById(sir.getSoId().getId()).get();
           si.setCustomer(so.getCustomer());
           si.setInvoiceAmount(invoiceAmount);
           si.setQuantity(quantity);
           si.setStoreId(so.getStoreId());
           SalesOrderAddress soa=salesOrderAddressRepository.findBySoIdId(sir.getSoId());
           si.setSoaId(new SalesOrderAddress().builder().id(soa.getId()).build());
           si.setCreatedDate(sir.getInvoiceDate());
           si.setCreatedBy(so.getCreatedBy());
               DeliveryNotes dn=deliveryNotesRepository.findBySoId(sir.getSoId());
              //System.out.println(deliveryChargesRepository.findByDnId(new DeliveryNotes().builder().id(dn.getId()).build()));
        
               DeliveryCharges dc=deliveryChargesRepository.findByDnId(new DeliveryNotes().builder().id(dn.getId()).build());
             
           si.setDeliveryCharges(dc.getCharges());

           SalesInvoices savesi=salesInvoicesRepository.save(si);


           System.out.println("save---------------------------------------");

                        List<SalesInvoiceItems> siilist=new ArrayList<>();
                        for(int i=0;i<sir.getSiir().size();i++)
                        {
                            SalesInvoiceItems sii=new SalesInvoiceItems();
                            sii.setItemId(new Items().builder().id(sir.getSiir().get(i).getItemId()).build());
                            sii.setQuantity(sir.getSiir().get(i).getQuantity());
                            Items items=itemsRepository.findById(sir.getSiir().get(i).getItemId()).get();
                            sii.setRate(items.getSellingPrice());
                            sii.setSiId(new SalesInvoices().builder().id( savesi.getId()).build());
                            sii.setTotalPrice(items.getMrp());
                            sii.setUomId(items.getUomId());
                            siilist.add(sii);
                            invoiceAmount=invoiceAmount+(items.getSellingPrice()*sir.getSiir().get(i).getQuantity());
                            quantity=quantity+sir.getSiir().get(i).getQuantity();
                        }
           salesInvoiceItemsRepository.saveAll(siilist);
           System.out.println("save items");

           si.setQuantity(quantity);
           si.setInvoiceAmount(invoiceAmount+dc.getCharges());
           si.setDueAmount(invoiceAmount+dc.getCharges());
           salesInvoicesRepository.save(si);
           

            ss.setStatuesCode("200");
            ss.setMessage(" save si ");
        }
        catch(Exception e)
        {
            ss.setStatuesCode("0");
            ss.setMessage("  "+e);
        }

        return ss;
    }

    @Override
    public List<SalesInvoices> getAllSalesInvoices(SalesInvoices salesInvoices) {
        
        return salesInvoicesRepository.findAll();
    }

    @Override
    public List<SalesInvoices> getBetweenDatesBySalesInvoices(String fromDate, String toDate) {
        
        return salesInvoicesRepository.findByInvoiceDateBetween(fromDate,toDate);
    }

    @Override
    public List<SalesInvoices> getSalesInvoicesByCustomerId(Customers customer) {
        
        return salesInvoicesRepository.findByCustomer(customer);
    }

    @Override
    public SalesInvoices getSalesInvoicesById(long id) {
        
        return salesInvoicesRepository.getOne(id);
    }

    @Override
    public List<SalesInvoices> getSalesInvoicesByStoreId(Stores storeId) {
        
        return salesInvoicesRepository.findByStoreId(storeId);
    }

//Customer receipts
@Autowired
private CustomerReceiptsRepository customerReceiptsRepository;
@Autowired
private CashBankAccountRepository cashBankAccountRepository;
@Autowired
private AccountsLogRepository accountsLogRepository;

@Transactional
    @Override
    public ServiceStatus saveCustomerReceipts(CustomerReceipts cr) {
    
        ServiceStatus ss= new ServiceStatus();
        try
        {
            customerReceiptsRepository.save(cr);

           SalesInvoices findsi=salesInvoicesRepository.findById(cr.getInvoiceId().getId()).get();
           /* SalesInvoices si =new SalesInvoices();
            si.setId(cr.getInvoiceId().getId());
            si.setCreatedBy(findsi.getCreatedBy());
            si.setCreatedDate(findsi.getCreatedDate());
            si.setCustomer(findsi.getCustomer());
            si.setDeliveryCharges(findsi.getDeliveryCharges());
            si.setInvoiceAmount(findsi.getInvoiceAmount());
            si.setInvoiceDate(findsi.getCreatedDate());
            si.setInvoiceNo(findsi.getInvoiceNo());
            si.setQuantity(findsi.getQuantity());
            si.setSoId(findsi.getSoId());
            si.setSoaId(findsi.getSoaId());
            si.setStoreId(findsi.getStoreId())*/
            findsi.setPaidAmount(cr.getAmount());
            findsi.setDueAmount(findsi.getDueAmount()-cr.getAmount());
            findsi.setModifiedBy(cr.getCreatedBy());
            findsi.setModifiedDate(cr.getCreatedDate());
            salesInvoicesRepository.save(findsi);
         AccountsLog al=new AccountsLog();
         al.setAmount(cr.getAmount());
         al.setTransactionDate(cr.getCreatedDate());
         al.setTransactionType("Credit");
         long id=1;
         CashBankAccount cba=cashBankAccountRepository.getById(id);
         al.setBalance(cba.getAmount()+cr.getAmount());
        accountsLogRepository.save(al);
        cba.setAmount(cba.getAmount()+cr.getAmount());
        cashBankAccountRepository.save(cba);

            
            ss.setStatuesCode("200");
            ss.setMessage(" save si ");
        }
        catch(Exception e)
        {
            ss.setStatuesCode("0");
            ss.setMessage("  "+e);
        }
        return ss;
    }

    @Override
    public List<CustomerReceipts> getAllCustomerReceipts(CustomerReceipts customerReceipts) {
        
        return customerReceiptsRepository.findAll();
    }

    @Override
    public CustomerReceipts getCustomerReceiptsById(long id) {
        
        return customerReceiptsRepository.findById(id).get();
    }

    @Override
    public List<CustomerReceipts> getBetweenDatesByCustomerReceipts(String fromDate, String toDate) {
        
        return null;
    }

    @Override
    public List<CustomerReceipts> getCustomerReceiptsByCustamarId(Customers customer) {

        List<CustomerReceipts> crlist=new ArrayList<>();

       List< SalesInvoices> si=salesInvoicesRepository.findByCustomer(customer);
        System.out.println(si);
        for(int i=0;i<si.size();i++)
        {
            System.out.println(new SalesInvoices().builder().id(si.get(i).getId()).build().getId());
            CustomerReceipts cr=customerReceiptsRepository.findByInvoiceId(new SalesInvoices().builder().id(si.get(i).getId()).build());
        
          crlist.add(cr);
        }
        System.out.println("return");
       return crlist;

    }

    
    
}
