package com.example.mg_project.reposiory.purchasesrepository;

import java.sql.Date;
import java.util.List;

import com.example.mg_project.entity.PurchaseInvoices;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.Vendors;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
@Repository
public interface PurchaseInvoicesRepository extends JpaRepository<PurchaseInvoices,Long>
{
    List<PurchaseInvoices> findByInvoiceDate(Date date);



    List<PurchaseInvoices> findByInvoiceDateBetween(Date fDate, Date tDate);

    List<PurchaseInvoices> findByVendor(Vendors vendor);

     List<PurchaseInvoices> findByStoreId(Stores storeId);

    List<PurchaseInvoices> findByStoreIdId(Stores storeId);
        


    
}
