package com.example.mg_project.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class CashBankAccount {
    @Id
    private long id;
    private Long accountNumber;
    private String holderName;
    private String phoneNumber;
    private String IFSC;
    private String banckBranch;
    private Double amount;

}
