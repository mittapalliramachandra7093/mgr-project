package com.example.mg_project.request.purchaserequest;

import java.util.Date;
import java.util.List;

import javax.persistence.ManyToOne;

import com.example.mg_project.entity.PurchaseOrders;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.Users;
import com.example.mg_project.entity.Vendors;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PurchaseInvoicesRequest {

    private PurchaseOrders poId;
    private String invoiceNo;
    private Date invoiceDate;

    private Date createdDate;
@ManyToOne
private Users createdBy;
private Stores storeId;
private Vendors vendor;
   List< PurchaseInvoiceItemsRequest >piir;



}
