package com.example.mg_project.entity;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class PurchaseOrders {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @ManyToOne
private Vendors vendor;
private Date orderDate;
private Double orderAmount;
private Integer quantity;
@ManyToOne
private Stores storeId;
private Date createdDate;
@ManyToOne
private Users createdBy;
private Date modifiedDate;
@ManyToOne
private Users modifiedBy;
}
