package com.example.mg_project.controller;
import java.util.List;
import com.example.mg_project.entity.CustomerReceipts;
import com.example.mg_project.entity.Customers;
import com.example.mg_project.entity.DeliveryCharges;
import com.example.mg_project.entity.DeliveryNoteItems;
import com.example.mg_project.entity.DeliveryNotes;
import com.example.mg_project.entity.LogisticExpenses;
import com.example.mg_project.entity.SalesInvoices;
import com.example.mg_project.entity.SalesOrderAddress;
import com.example.mg_project.entity.SalesOrderItems;
import com.example.mg_project.entity.SalesOrder;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.request.salesrequest.DeliveryNotesReguest;
import com.example.mg_project.request.salesrequest.SalesInvoicesRequest;
import com.example.mg_project.request.salesrequest.SalesOrdersRequest;
import com.example.mg_project.service.SalesService;
import com.example.mg_project.servicestatus.ServiceStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/sales")
public class SalesCountroller {
    @Autowired
    private SalesService salesService;
// customers
    @PostMapping("/savecustomers")
    public Customers saveCustomers(@RequestBody Customers customers)
    {
        return salesService.saveCustomers(customers);
    }
    @GetMapping("/getcustomersbyid/{id}")
    public Customers getCustomersById(@PathVariable("id") long id)
    {
        return salesService.getCustomersById(id);
    }
    @GetMapping("/getcustomers")
    public List<Customers> getAllCustomers(Customers customers)
    {
        return salesService.getAllCustomers(customers);
    }
  //sales orders
  @PostMapping("/savesalesorders")
  public ServiceStatus saveSalesOrders(@RequestBody SalesOrdersRequest salesoOrdersRequest)
  {
      return salesService.saveSalesOrders(salesoOrdersRequest);
  }
  @GetMapping("/getsalesorders")
  public List<SalesOrder> getAllSalesOrders(SalesOrder salesOrders)
  {
      return salesService.getAllSalesOrders(salesOrders);
  }
  @GetMapping("/getsalesordersbyid/{id}")
  public SalesOrder getSalesOrdersById(@PathVariable("id") long id)
  {
      return salesService.getSalesOrdersById(id);
  }
  //---

  @GetMapping("/getsoitemsbysoid/{id}")
  public SalesOrderItems getSoItemsBySoId(@PathVariable("id") SalesOrder soId)
  {
      return salesService.getSoItemsBySoId(soId);
  }
  @GetMapping("/getsoaddressbysoid/{id}")
  public SalesOrderAddress getSalesOrderAddressBySoId(@PathVariable("id") SalesOrder soId)
  {
      return salesService.getSalesOrderAddressBySoId(soId);
  }

  @GetMapping("/getsalesorders/{fromDate}/{toDate}")
  public  List<SalesOrder> getBetweenSalesOrders(@PathVariable String fromDate,@PathVariable String toDate)
{
    return salesService.getBetweenDatesBySalesOrders(fromDate,toDate);
} 
// LogisticExpenses
  @GetMapping("/getsolebysoid/{id}")
  public LogisticExpenses getLogisticExpensesBySoId(@PathVariable("id") SalesOrder soId)
  {
      return salesService.getLogisticExpensesBySoId(soId);
  }

  //DeliveryNote

  @PostMapping("/deliverynote")
  public ServiceStatus saveDeliveryNotes(@RequestBody DeliveryNotesReguest deliveryNotesReguest)
  {
      return salesService.saveDeliveryNotes(deliveryNotesReguest);
  }

  @GetMapping("/getdeliverynotes")
  public List<DeliveryNotes> getAllDeliveryNotes(DeliveryNotes deliveryNotes)
  {
      return salesService.getAllDeliveryNotes(deliveryNotes);
  }


  @GetMapping("/getdnbyid/{id}")
  public DeliveryNotes getDeliveryNotesById(@PathVariable("id") long id)
  {
      return salesService.getDeliveryNotesById(id);
  }
//DeliveryNotesItems
  @GetMapping("/getdnitemsbydnid/{id}")
  public List< DeliveryNoteItems> getDeliveryNotesItemsByDeliveryNotesId(@PathVariable("id") DeliveryNotes dnId)
  {
      return salesService.getDeliveryNotesItemsByDeliveryNotesId(dnId);
  }
//DeliveryCharges
  @GetMapping("/getdeliverychargesbydnid/{id}")
  public DeliveryCharges getDeliveryChargesByDeliveryNotesId(@PathVariable("id") DeliveryNotes dnId)
  {
      return salesService.getDeliveryChargesByDeliveryNotesId(dnId);
  }

// SalesInvoices

  @PostMapping("/savesalesinvoice")
  public ServiceStatus saveSalesInvoices(@RequestBody SalesInvoicesRequest sir)
  {
      return salesService.saveSalesInvoices(sir);
  }

  @GetMapping("/getsalesinvoices")
  public List<SalesInvoices> getAllSalesInvoices(SalesInvoices salesInvoices)
  {
      return salesService.getAllSalesInvoices(salesInvoices);
  }

  @GetMapping("/getsalesinvoices/{fromDate}/{toDate}")
  public  List<SalesInvoices> getBetweenSalesInvoices(@PathVariable String fromDate,@PathVariable String toDate)
{
    return salesService.getBetweenDatesBySalesInvoices(fromDate,toDate);
}


  @GetMapping("/getsibycustomerid/{id}")
  public List<SalesInvoices> getSalesInvoicesByCustomerId(@PathVariable("id") Customers customer)
  {
      return salesService.getSalesInvoicesByCustomerId(customer);
  }

  @GetMapping("/getsalesinvoices/{id}")
  public SalesInvoices getSalesInvoicesById(@PathVariable("id") long id)
  {
      return salesService.getSalesInvoicesById(id);
  }

  @GetMapping("/getsibystoreid/{id}")
  public List< SalesInvoices> getSalesInvoicesByStoreId(@PathVariable("id") Stores storeId)
  {
      return salesService.getSalesInvoicesByStoreId(storeId);
  }

//CustomerReceipts

  @PostMapping("/savecustomerreceipts")
  public ServiceStatus saveCustomerReceipts(@RequestBody CustomerReceipts cr)
  {
      return salesService.saveCustomerReceipts(cr);
  }

  @GetMapping("/customerreceipts")
  public List<CustomerReceipts> getAllCustomerReceipts(CustomerReceipts customerReceipts)
  {
      return salesService.getAllCustomerReceipts(customerReceipts);
  }

  @GetMapping("/getcustomerreceipts/{id}")
  public CustomerReceipts getCustomerReceiptsById(@PathVariable("id") long id)
  {
      return salesService.getCustomerReceiptsById(id);
  }

  @GetMapping("/getcrbycustomerid/{id}")
  public List <CustomerReceipts> getCustomerReceiptsByCustamarId(@PathVariable("id") Customers customer)
  {
      return salesService.getCustomerReceiptsByCustamarId(customer);
  }

  @GetMapping("/getcustomerreceipts/{fromDate}/{toDate}")
  public  List<CustomerReceipts > getBetweenCustomerReceiptss(@PathVariable String fromDate,@PathVariable String toDate)
{
    return salesService.getBetweenDatesByCustomerReceipts(fromDate,toDate);
}
    
}

