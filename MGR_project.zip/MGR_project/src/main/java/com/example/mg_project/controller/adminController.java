package com.example.mg_project.controller;
import java.util.List;

import com.example.mg_project.entity.Areas;
import com.example.mg_project.entity.Cities;
import com.example.mg_project.entity.Country;
import com.example.mg_project.entity.Login;
import com.example.mg_project.entity.States;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.Users;
import com.example.mg_project.service.AdminService;
import com.example.mg_project.servicestatus.ServiceStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;



@Controller
@RequestMapping("/admin")
public class adminController 
{

    @Autowired
    private AdminService usersService;
//user
    @RequestMapping("/saveuser")
    public String saveuser(Users users)
    { 
         usersService.saveuser(users);
         return "RegisteredSuccess";
    }
    @ResponseBody
    @GetMapping("/getuserbyid")
    public Users  getUserById( String na)
    {
        System.out.println("grt users api =========================================="+na);
        long nna=Long.parseLong(na);
        return usersService.getUserById(nna); 
     
    }
    @ResponseBody
    @GetMapping("/getusersbystatus/{status}")
    public List< Users> getUsersByStatus(@PathVariable("status") Boolean status)
    {
        return usersService.getUsersByStatus(status);
    }

//login

   @PostMapping("/login")
    public  String validatelogin(Login login )
    {
        
        ServiceStatus ss= usersService.validatelogin(login);
        if(ss.getStatuesCode().equals("200"))
        {
       return "About";
        }
        else if(ss.getStatuesCode().equals("0"))
        {
            return "Home";
        }
        else{
            return "Login";
        }

         
    }

//country
@PostMapping("/savecountry")
    public String savecountry(Country country)
    {
         usersService.savecountry(country);
         return "RegisteredSuccess";
    }
    @ResponseBody
@GetMapping("/getcountrybyid/{id}")
public Country getCountryById(@PathVariable("id") long countryid)
{
    return usersService.getCountryById(countryid);
}

//states
@PostMapping("/savestates")
    public String saveStates(@RequestBody States states)
    {
         usersService.saveStates(states);
         return "RegisteredSuccess";
    }

@GetMapping("/getstates")
public String allStates(Model module)
{
    
  List<States>stateslist= usersService.allStates();
  module.addAttribute("st", stateslist);
    return "AllStates";
}
@ResponseBody
@GetMapping("/getstates/{id}")
public States getStatesById(@PathVariable("id") long statesid)
{
return usersService.getStatesById(statesid);
}
@ResponseBody
@GetMapping("/getstatesbycountryid/{id}")
public List<States> allStatesByCountryId(@PathVariable("id") Country countryId)
{
    return usersService.getstatesbycountryid(countryId);
}

//cities
@PostMapping("/savecity")
public String saveCitie(@RequestBody Cities cities)
{
     usersService.saveCitie(cities);
     return "RegisteredSuccess";
}
@ResponseBody
@GetMapping("/getcitysbyid/{id}")
public Cities getCityById(@PathVariable("id") long id)
{
return usersService.getCityById(id);
}
@ResponseBody
@GetMapping("/getallcitys")
public List<Cities> allCitys(Cities cities)
{
    return usersService.allCitys(cities);
}
@ResponseBody
@GetMapping("/getcitysbystateid/{id}")
public List<Cities> getAllCitysByStatesId(@PathVariable("id") States stateId )
{
    return usersService.getAllCitysByStatesId(stateId);
}

//Areas
@PostMapping("/saveareas")
public String saveAreas(@RequestBody Areas areas)
{
     usersService.saveAreas(areas);
     return "RegisteredSuccess";
}
@ResponseBody
@GetMapping("/getareas/{id}")
public Areas getAreasById(@PathVariable("id") long id )
{
    return usersService.getAreasbyId(id);
}
@ResponseBody
@GetMapping("/getareas")
public List<Areas> getAllAreas(Areas areas)
{
    return usersService.getAllAreas(areas);
}
@ResponseBody
@GetMapping("/getareabycityid/{id}")
public List<Areas> getAreaByCityId(@PathVariable("id") Cities cityId)
{
    return usersService.getAreaByCityId(cityId);
}

//stores
@PostMapping("/savestores")
public String saveStores(@RequestBody Stores stores)
{
     usersService.saveStores(stores);
     return "RegisteredSuccess";
}
@ResponseBody
@GetMapping("/getstoresbyid/{id}")
public Stores getStoresById(@PathVariable("id")long id )
{
return usersService.getStoresById(id);
}
@ResponseBody
@GetMapping("/getallstores")
    public List<Stores> getAllStores(Stores stores)
    {
        return usersService.getAllStores(stores);
    }
    @ResponseBody
@GetMapping("/getstoresbyareaid/{id}")
public Stores getStoresByAreaId(@PathVariable("id") Areas areaId) {
    return usersService.getStoresByAreaId(areaId);
}
@ResponseBody
@GetMapping("/getstoresbypincode/{pincode}")
public List<Stores> getStoresByPincode(@PathVariable("pincode") String pincode)
{
    return usersService.getStoresByPincode(pincode);
}


}
