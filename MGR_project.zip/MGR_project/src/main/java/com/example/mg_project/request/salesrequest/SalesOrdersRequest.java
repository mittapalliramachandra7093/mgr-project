package com.example.mg_project.request.salesrequest;
import java.util.List;
import com.example.mg_project.entity.Customers;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.Users;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SalesOrdersRequest {
    
    private Customers customer;
    private String orderDate;
    private Users createdBy;
    private Stores storeId;
    
    List<SalesOrderItemRequest> soir;

   private SalesOrderAddressRequest soar;
    
    
}
