package com.example.mg_project.reposiory.salesrepository;

import java.util.List;

import com.example.mg_project.entity.DeliveryNoteItems;
import com.example.mg_project.entity.DeliveryNotes;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DeliveryNoteItemsRepository extends JpaRepository<DeliveryNoteItems,Long>
{

    List<DeliveryNoteItems> findByDnId(DeliveryNotes dnId);
    
}
