package com.example.mg_project.reposiory.inventoryrepository;

import java.util.List;

import com.example.mg_project.entity.Items;
import com.example.mg_project.entity.Stock;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.Stock.StockBuilder;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StockRepository extends JpaRepository<Stock,Long>
 {

    Stock findByItemId(Items itemId);


Stock findByStoreIdAndItemId(Stores build, Items build2);

List<Stock> findByStoreId(Stores build);


List<Stock> findByStoreId(Stock build);

    
}
