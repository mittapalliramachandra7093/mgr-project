package com.example.mg_project.service;

import java.util.List;

import com.example.mg_project.entity.CustomerReceipts;
import com.example.mg_project.entity.Customers;
import com.example.mg_project.entity.DeliveryCharges;
import com.example.mg_project.entity.DeliveryNoteItems;
import com.example.mg_project.entity.DeliveryNotes;
import com.example.mg_project.entity.LogisticExpenses;
import com.example.mg_project.entity.SalesInvoices;
import com.example.mg_project.entity.SalesOrderAddress;
import com.example.mg_project.entity.SalesOrderItems;
import com.example.mg_project.entity.SalesOrder;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.request.salesrequest.DeliveryNotesReguest;
import com.example.mg_project.request.salesrequest.SalesInvoicesRequest;
import com.example.mg_project.request.salesrequest.SalesOrdersRequest;
import com.example.mg_project.servicestatus.ServiceStatus;


public interface SalesService {

    Customers saveCustomers(Customers customers);

    Customers getCustomersById(long id);

    List<Customers> getAllCustomers(Customers customers);
//sales orders
    ServiceStatus saveSalesOrders(SalesOrdersRequest salesOrdersRequest);

    List<SalesOrder> getAllSalesOrders(SalesOrder salesOrders);

    SalesOrder getSalesOrdersById(long id);

    SalesOrderItems getSoItemsBySoId(SalesOrder soId);

    SalesOrderAddress getSalesOrderAddressBySoId(SalesOrder soId);

    List<SalesOrder> getBetweenDatesBySalesOrders(String fromDate, String toDate);

    LogisticExpenses getLogisticExpensesBySoId(SalesOrder soId);
//delivary
    ServiceStatus saveDeliveryNotes(DeliveryNotesReguest deliveryNotesReguest);

    List<DeliveryNotes> getAllDeliveryNotes(DeliveryNotes deliveryNotes);

    DeliveryNotes getDeliveryNotesById(long id);
//delivery note items
    List<DeliveryNoteItems> getDeliveryNotesItemsByDeliveryNotesId(DeliveryNotes dnId);

    DeliveryCharges getDeliveryChargesByDeliveryNotesId(DeliveryNotes dnId);

//  SalesInvoices
    ServiceStatus saveSalesInvoices(SalesInvoicesRequest sir);

    List<SalesInvoices> getAllSalesInvoices(SalesInvoices salesInvoices);

    List<SalesInvoices> getBetweenDatesBySalesInvoices(String fromDate, String toDate);

   List< SalesInvoices> getSalesInvoicesByCustomerId(Customers customer);

    SalesInvoices getSalesInvoicesById(long id);

    List<SalesInvoices> getSalesInvoicesByStoreId(Stores storeId);

    //

    ServiceStatus saveCustomerReceipts(CustomerReceipts cr);

    List<CustomerReceipts> getAllCustomerReceipts(CustomerReceipts customerReceipts);

    CustomerReceipts getCustomerReceiptsById(long id);

    List<CustomerReceipts> getBetweenDatesByCustomerReceipts(String fromDate, String toDate);

    List<CustomerReceipts> getCustomerReceiptsByCustamarId(Customers customer);


    


    
}
