package com.example.mg_project.entity;

public class request {

}
