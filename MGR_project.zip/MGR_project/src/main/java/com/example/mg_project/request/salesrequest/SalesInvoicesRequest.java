package com.example.mg_project.request.salesrequest;

import java.util.Date;
import java.util.List;

import com.example.mg_project.entity.SalesOrder;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class SalesInvoicesRequest {

    private SalesOrder soId;
    private String invoiceNo;
    private Date invoiceDate;
   List<SalesInvoicesItemsRequest> siir;

}
