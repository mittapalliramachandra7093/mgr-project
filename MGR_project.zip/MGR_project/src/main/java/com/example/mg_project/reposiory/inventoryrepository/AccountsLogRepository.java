package com.example.mg_project.reposiory.inventoryrepository;

import com.example.mg_project.entity.AccountsLog;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AccountsLogRepository extends JpaRepository<AccountsLog,Long>
{
    
}
