package com.example.mg_project.service;
import java.util.ArrayList;
import java.util.List;

import com.example.mg_project.entity.Areas;
import com.example.mg_project.entity.Cities;
import com.example.mg_project.entity.Country;
import com.example.mg_project.entity.Login;
import com.example.mg_project.entity.States;
import com.example.mg_project.entity.Stores;
import com.example.mg_project.entity.Users;
import com.example.mg_project.reposiory.adminRepository.UsersRepository;
import com.example.mg_project.reposiory.adminRepository.AreasRepository;
import com.example.mg_project.reposiory.adminRepository.CitiesRepository;
import com.example.mg_project.reposiory.adminRepository.CountryRepository;
import com.example.mg_project.reposiory.adminRepository.StatesRepository;
import com.example.mg_project.reposiory.adminRepository.StoresRepository;

import com.example.mg_project.servicestatus.ServiceStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
@Service
public class AdminServiceImpl implements AdminService
{
//user
    @Autowired
    private UsersRepository usersRepository;

    @Override
    public Users saveuser(Users users) {
        
        return usersRepository.save(users);
    }

    @Override
    public Users getUserById(long userId) {
        
        return usersRepository.findById(userId).get();
    }
    @Override
    public List<Users> getUsersByStatus(Boolean status) {
        
        return usersRepository.findByStatus(status);
    }

//login 
 private ServiceStatus ss;
@Override
public ServiceStatus validatelogin(Login login) {
    

    ss=new ServiceStatus();
    try{
            String loginUname=login.getUsername();
            String loginUpassword=login.getPassword();
            Users users=usersRepository.findByUsername(loginUname).get();
            String uname=users.getUsername();
            String upassword=users.getPassword();
            if((loginUname.equals(uname))&&(loginUpassword.equals(upassword)))
            {
                
                ss.setStatuesCode("200");
               ss.setMessage("well come  "+uname+" valid account");
                
            }
            else{
               ss.setStatuesCode("201");
                ss.setMessage("User name and password not valid");
            
            }
      }
   catch(Exception e)
    {
             ss.setStatuesCode("0");
             ss.setMessage("user not register");
    }
    finally
    {
      return ss;
    }
           
                
} 

//country
    @Autowired
    private CountryRepository countryRepository;
    @Override
    public Country savecountry(Country country) {
        return countryRepository.save(country);
    }

    @Override
    public Country getCountryById(long countryid) {
        
        return countryRepository.findById(countryid).get();
    }

//states

@Autowired
private StatesRepository statesRepository;

    @Override
    public States saveStates(States states) {
        
        return  statesRepository.save(states);
    }

    @Override
    public List<States> allStates() {
        
        List<States> lss= statesRepository.findAll();
        List<States> stateslist= new ArrayList<States>();
        for(int i=0;i<lss.size();i++)
        {
        States s=new States();
       s.setId(lss.get(i).getId());
       s.setStateName(lss.get(i).getStateName());
       stateslist.add(s);
        }
        
         return stateslist;
    }
    @Override
    public List<States> getstatesbycountryid(Country countryId) {
                                                  //calumname but falo camelcasegv
    
        List<States> lss= statesRepository.findByCountryId(countryId);
        List<States> stateslist= new ArrayList<States>();
        for(int i=0;i<lss.size();i++)
        {
        States s=new States();
       s.setId(lss.get(i).getId());
       s.setStateName(lss.get(i).getStateName());
       stateslist.add(s);
        }
        
         return stateslist;
    }

    @Override
    public States getStatesById(long statesid) {
        
        return statesRepository.findById(statesid).get();
    }

//cities
@Autowired
private CitiesRepository citiesRepository;
    @Override
    public Cities saveCitie(Cities cities) {
        
        return citiesRepository.save(cities);
    }

    @Override
    public Cities getCityById(long id) {
        
        return citiesRepository.findById(id).get();
    }

    @Override
    public List<Cities> allCitys(Cities cities) {
    
        return citiesRepository.findAll();
    }

    @Override
    public List<Cities> getAllCitysByStatesId(States stateId) {
    
        return (List<Cities>) citiesRepository.findByStateId(stateId);
    }

//Areas
@Autowired
private AreasRepository areasRepository;

    @Override
    public Areas saveAreas(Areas areas) {

        return areasRepository.save(areas);
    }

    @Override
    public Areas getAreasbyId(long id) {
        
        return areasRepository.findById(id).get();
    }

    @Override
    public List<Areas> getAllAreas(Areas areas) {
        
        return areasRepository.findAll();
    }

    @Override
    public List<Areas> getAreaByCityId(Cities cityId) {
        
        return areasRepository.findByCityId(cityId);
    }

//stores

@Autowired
private StoresRepository storesRepository;

    @Override
    public Stores saveStores(Stores stores) {
        
        return storesRepository.save(stores);
    }

    @Override
    public Stores getStoresById(long id) {
        
        return storesRepository.findById(id).get();
    }

    @Override
    public List<Stores> getAllStores(Stores stores) {
        
        return storesRepository.findAll();
    }

    @Override
    public Stores getStoresByAreaId(Areas areaId) {
    
        return storesRepository.findByAreaId(areaId);
    }

    @Override
    public List<Stores> getStoresByPincode(String pincode) {
        
        return storesRepository.findByPincode(pincode);
    }


    


  

    

    
    
}
