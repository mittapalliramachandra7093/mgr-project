package com.example.mg_project.response;

import java.util.Date;

import lombok.Data;
@Data
public class DuePaymentsResponse {

    private Date InvoiceDate;
    private String InvoiceNumber;
    private String VendorName; 
    private Double InvoiceAmount;
    private Double  PaidAmount ;
    private Double DueAmount;
     // DueDate;
    
}
