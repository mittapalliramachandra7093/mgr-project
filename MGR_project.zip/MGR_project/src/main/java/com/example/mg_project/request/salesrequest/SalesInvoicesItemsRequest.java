package com.example.mg_project.request.salesrequest;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SalesInvoicesItemsRequest {

    private long itemId;
private Integer quantity;
    
}
