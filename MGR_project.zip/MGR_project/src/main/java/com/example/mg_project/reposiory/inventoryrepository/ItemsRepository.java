package com.example.mg_project.reposiory.inventoryrepository;


import com.example.mg_project.entity.Items;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ItemsRepository extends JpaRepository<Items,Long>
{
    
}
