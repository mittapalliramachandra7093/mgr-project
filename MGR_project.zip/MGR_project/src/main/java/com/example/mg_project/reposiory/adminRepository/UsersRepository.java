package com.example.mg_project.reposiory.adminRepository;

import java.util.List;
import java.util.Optional;

import com.example.mg_project.entity.Users;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsersRepository extends JpaRepository<Users,Long>
{

    Optional<Users> findByUsername(String uname);

    List<Users> findByStatus(Boolean status);




}
