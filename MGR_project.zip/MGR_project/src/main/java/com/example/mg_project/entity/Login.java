package com.example.mg_project.entity;
import javax.persistence.Entity;
import javax.persistence.Id;
import lombok.*;


@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Login 
{
    @Id
    private String username;
    private String password;
}
