package com.example.mg_project.entity;
import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SalesInvoices {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
private String invoiceNo;
@ManyToOne
private Customers customer;
private Date invoiceDate;
private Double invoiceAmount;
private Double deliveryCharges;
private Double dueAmount;
private Double paidAmount;
private Integer quantity;
@ManyToOne
private Stores storeId;
@ManyToOne
private SalesOrderAddress soaId;
private Date createdDate;
@ManyToOne
private Users createdBy;
private Date modifiedDate;
@ManyToOne
private Users modifiedBy;
@ManyToOne
private SalesOrder soId;

    
}
