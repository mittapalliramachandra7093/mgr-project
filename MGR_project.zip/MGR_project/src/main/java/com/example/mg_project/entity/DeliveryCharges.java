package com.example.mg_project.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class DeliveryCharges {
    @Id
    @GeneratedValue
    private Long id;
    @OneToOne
private DeliveryNotes dnId;
private Double distance;
private Double charges;

    
}
