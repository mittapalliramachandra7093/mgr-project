package com.example.mg_project.entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Customers {
    @Id
    private Long id;
private String customerName;
private String mobile;
private String email;
@ManyToOne 
private Areas areaId;
private String pincode;
private Date createdDate;
@ManyToOne
private Users createdBy;
private Date modifiedDate;
@ManyToOne
private Users modifiedBy;


}
