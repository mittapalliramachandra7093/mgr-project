package com.example.mg_project.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Items {
    @Id
    private Long id;
private String itemCode;
private String itemName;
private Double mrp;
private Double costPrice;
private Double sellingPrice;
@ManyToOne
private Category categoryId;
@OneToOne
private UOM uomId;

}