package com.example.mg_project.reposiory.salesrepository;

import com.example.mg_project.entity.DeliveryNotes;
import com.example.mg_project.entity.SalesOrder;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DeliveryNotesRepository extends JpaRepository<DeliveryNotes,Long>
{

    DeliveryNotes findBySoId(SalesOrder soId);
    
}
