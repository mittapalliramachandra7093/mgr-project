package com.example.mg_project.response;

import lombok.Data;

@Data
public class Reorderlevelreports 
{

   private String  StoreName;
   private  String ItemName;
   private  long  Qty;
   private  long   Reorder;
   private   long Overflow;
    
}
