package com.example.mg_project.reposiory.adminRepository;

import java.util.List;

import com.example.mg_project.entity.Country;
import com.example.mg_project.entity.States;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StatesRepository extends JpaRepository<States,Long>
{

    List<States> findByCountryId(Country countryId);
    
}
