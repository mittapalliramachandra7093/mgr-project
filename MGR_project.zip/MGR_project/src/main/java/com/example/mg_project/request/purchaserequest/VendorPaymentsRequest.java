package com.example.mg_project.request.purchaserequest;

import java.util.Date;

import com.example.mg_project.entity.PaymentModes;
import com.example.mg_project.entity.PurchaseInvoices;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class VendorPaymentsRequest {

    private PurchaseInvoices invoiceId;
    private Double paidAmount;
    private Date paymentDate;
    private PaymentModes modeId;
}
