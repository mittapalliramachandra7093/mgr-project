package com.example.mg_project.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class SalesInvoiceItems {
    @Id
    @GeneratedValue
    private Long id;
    @ManyToOne
private SalesInvoices siId;
@ManyToOne
private Items itemId;
private Integer quantity;
private Double rate;
@OneToOne
private UOM uomId;
private Double totalPrice;

}
