package com.example.mg_project.response;

import lombok.Data;

@Data
public class HighestCustomerSales {
   private String CustomerName;
   private String Mobile;
   private Integer TimesOrdered;
   private  Double TotalAmount;
    
}
