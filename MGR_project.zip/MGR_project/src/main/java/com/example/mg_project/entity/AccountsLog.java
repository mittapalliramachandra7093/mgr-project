package com.example.mg_project.entity;

import java.util.Date;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class AccountsLog {
    @Id
    @GeneratedValue
    private Long id;
private Double amount;
private String transactionType;
private Date transactionDate;
private Double balance;
   
}
