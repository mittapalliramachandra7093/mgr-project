package com.example.mg_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MgProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
